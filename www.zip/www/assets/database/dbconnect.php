<?php

  define('HOST','localhost');
  # define('USER','root');
  define('USER','id8247064_chapadmin');
  # define('PASS','');
  define('PASS','chap_123321');
  # define('DB','CHAP_LOGINDB');
  define('DB','id8247064_chap_logindb');

  $con = mysqli_connect(HOST,USER,PASS,DB);
  if (!$con) {
    die("Error in connection" . mysqli_connect_error()) ;
  }

?>