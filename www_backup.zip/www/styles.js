(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["styles"],{

/***/ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/global.scss":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src??embedded!./node_modules/sass-loader/lib/loader.js??ref--14-3!./src/global.scss ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = [[module.i, "html.ios{--ion-default-font: -apple-system, BlinkMacSystemFont, \"Helvetica Neue\", \"Roboto\", sans-serif}html.md{--ion-default-font: \"Roboto\", \"Helvetica Neue\", sans-serif}html{--ion-font-family: var(--ion-default-font)}body.backdrop-no-scroll{overflow:hidden}.ion-color-primary{--ion-color-base: var(--ion-color-primary, #3880ff) !important;--ion-color-base-rgb: var(--ion-color-primary-rgb, 56,128,255) !important;--ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-primary-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-primary-shade, #3171e0) !important;--ion-color-tint: var(--ion-color-primary-tint, #4c8dff) !important}.ion-color-secondary{--ion-color-base: var(--ion-color-secondary, #0cd1e8) !important;--ion-color-base-rgb: var(--ion-color-secondary-rgb, 12,209,232) !important;--ion-color-contrast: var(--ion-color-secondary-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-secondary-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-secondary-shade, #0bb8cc) !important;--ion-color-tint: var(--ion-color-secondary-tint, #24d6ea) !important}.ion-color-tertiary{--ion-color-base: var(--ion-color-tertiary, #7044ff) !important;--ion-color-base-rgb: var(--ion-color-tertiary-rgb, 112,68,255) !important;--ion-color-contrast: var(--ion-color-tertiary-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-tertiary-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-tertiary-shade, #633ce0) !important;--ion-color-tint: var(--ion-color-tertiary-tint, #7e57ff) !important}.ion-color-success{--ion-color-base: var(--ion-color-success, #10dc60) !important;--ion-color-base-rgb: var(--ion-color-success-rgb, 16,220,96) !important;--ion-color-contrast: var(--ion-color-success-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-success-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-success-shade, #0ec254) !important;--ion-color-tint: var(--ion-color-success-tint, #28e070) !important}.ion-color-warning{--ion-color-base: var(--ion-color-warning, #ffce00) !important;--ion-color-base-rgb: var(--ion-color-warning-rgb, 255,206,0) !important;--ion-color-contrast: var(--ion-color-warning-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-warning-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-warning-shade, #e0b500) !important;--ion-color-tint: var(--ion-color-warning-tint, #ffd31a) !important}.ion-color-danger{--ion-color-base: var(--ion-color-danger, #f04141) !important;--ion-color-base-rgb: var(--ion-color-danger-rgb, 240,65,65) !important;--ion-color-contrast: var(--ion-color-danger-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-danger-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-danger-shade, #d33939) !important;--ion-color-tint: var(--ion-color-danger-tint, #f25454) !important}.ion-color-light{--ion-color-base: var(--ion-color-light, #f4f5f8) !important;--ion-color-base-rgb: var(--ion-color-light-rgb, 244,245,248) !important;--ion-color-contrast: var(--ion-color-light-contrast, #000) !important;--ion-color-contrast-rgb: var(--ion-color-light-contrast-rgb, 0,0,0) !important;--ion-color-shade: var(--ion-color-light-shade, #d7d8da) !important;--ion-color-tint: var(--ion-color-light-tint, #f5f6f9) !important}.ion-color-medium{--ion-color-base: var(--ion-color-medium, #989aa2) !important;--ion-color-base-rgb: var(--ion-color-medium-rgb, 152,154,162) !important;--ion-color-contrast: var(--ion-color-medium-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-medium-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-medium-shade, #86888f) !important;--ion-color-tint: var(--ion-color-medium-tint, #a2a4ab) !important}.ion-color-dark{--ion-color-base: var(--ion-color-dark, #222428) !important;--ion-color-base-rgb: var(--ion-color-dark-rgb, 34,36,40) !important;--ion-color-contrast: var(--ion-color-dark-contrast, #fff) !important;--ion-color-contrast-rgb: var(--ion-color-dark-contrast-rgb, 255,255,255) !important;--ion-color-shade: var(--ion-color-dark-shade, #1e2023) !important;--ion-color-tint: var(--ion-color-dark-tint, #383a3e) !important}.ion-page{left:0;right:0;top:0;bottom:0;display:flex;position:absolute;flex-direction:column;justify-content:space-between;contain:layout size style;overflow:hidden;z-index:0}ion-route,ion-route-redirect,ion-router,ion-animation-controller,ion-nav-controller,ion-menu-controller,ion-action-sheet-controller,ion-alert-controller,ion-loading-controller,ion-modal-controller,ion-picker-controller,ion-popover-controller,ion-toast-controller,.ion-page-hidden,[hidden]{display:none !important}.ion-page-invisible{opacity:0}html.plt-ios.plt-hybrid,html.plt-ios.plt-pwa{--ion-statusbar-padding: 20px}@supports (padding-top: 20px){html{--ion-safe-area-top: var(--ion-statusbar-padding)}}@supports (padding-top: constant(safe-area-inset-top)){html{--ion-safe-area-top: constant(safe-area-inset-top);--ion-safe-area-bottom: constant(safe-area-inset-bottom);--ion-safe-area-left: constant(safe-area-inset-left);--ion-safe-area-right: constant(safe-area-inset-right)}}@supports (padding-top: env(safe-area-inset-top)){html{--ion-safe-area-top: env(safe-area-inset-top);--ion-safe-area-bottom: env(safe-area-inset-bottom);--ion-safe-area-left: env(safe-area-inset-left);--ion-safe-area-right: env(safe-area-inset-right)}}audio,canvas,progress,video{vertical-align:baseline}audio:not([controls]){display:none;height:0}b,strong{font-weight:bold}img{max-width:100%;border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{height:1px;border-width:0;box-sizing:content-box}pre{overflow:auto}code,kbd,pre,samp{font-family:monospace, monospace;font-size:1em}label,input,select,textarea{font-family:inherit;line-height:normal}textarea{overflow:auto;height:auto;font:inherit;color:inherit}textarea::-webkit-input-placeholder{padding-left:2px}textarea::-moz-placeholder{padding-left:2px}textarea::-ms-input-placeholder{padding-left:2px}textarea::placeholder{padding-left:2px}form,input,optgroup,select{margin:0;font:inherit;color:inherit}html input[type=\"button\"],input[type=\"reset\"],input[type=\"submit\"]{cursor:pointer;-webkit-appearance:button}a,a div,a span,a ion-icon,a ion-label,button,button div,button span,button ion-icon,button ion-label,[tappable],[tappable] div,[tappable] span,[tappable] ion-icon,[tappable] ion-label,input,textarea{touch-action:manipulation}a ion-label,button ion-label{pointer-events:none}button{border:0;border-radius:0;font-family:inherit;font-style:inherit;font-variant:inherit;line-height:1;text-transform:none;cursor:pointer;-webkit-appearance:button}[tappable]{cursor:pointer}a[disabled],button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0}input[type=\"checkbox\"],input[type=\"radio\"]{padding:0;box-sizing:border-box}input[type=\"number\"]::-webkit-inner-spin-button,input[type=\"number\"]::-webkit-outer-spin-button{height:auto}input[type=\"search\"]::-webkit-search-cancel-button,input[type=\"search\"]::-webkit-search-decoration{-webkit-appearance:none}table{border-collapse:collapse;border-spacing:0}td,th{padding:0}*{box-sizing:border-box;-webkit-tap-highlight-color:rgba(0,0,0,0);-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none}html{width:100%;height:100%;-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}body{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;margin:0;padding:0;position:fixed;width:100%;max-width:100%;height:100%;max-height:100%;text-rendering:optimizeLegibility;overflow:hidden;touch-action:manipulation;-webkit-user-drag:none;-ms-content-zooming:none;word-wrap:break-word;overscroll-behavior-y:none;-webkit-text-size-adjust:none;-moz-text-size-adjust:none;-ms-text-size-adjust:none;text-size-adjust:none}html{font-family:var(--ion-font-family)}a{background-color:transparent;color:var(--ion-color-primary, #3880ff)}h1,h2,h3,h4,h5,h6{margin-top:16px;margin-bottom:10px;font-weight:500;line-height:1.2}h1{margin-top:20px;font-size:26px}h2{margin-top:18px;font-size:24px}h3{font-size:22px}h4{font-size:20px}h5{font-size:18px}h6{font-size:16px}small{font-size:75%}sub,sup{position:relative;font-size:75%;line-height:0;vertical-align:baseline}sup{top:-.5em}sub{bottom:-.25em}[no-padding]{--padding-start: 0;--padding-end: 0;--padding-top: 0;--padding-bottom: 0;padding:0}[padding]{--padding-start: var(--ion-padding, 16px);--padding-end: var(--ion-padding, 16px);--padding-top: var(--ion-padding, 16px);--padding-bottom: var(--ion-padding, 16px);padding:var(--ion-padding, 16px)}[padding-top]{--padding-top: var(--ion-padding, 16px);padding-top:var(--ion-padding, 16px)}[padding-start]{--padding-start: var(--ion-padding, 16px);padding-left:var(--ion-padding, 16px)}[padding-end]{--padding-end: var(--ion-padding, 16px);padding-right:var(--ion-padding, 16px)}[padding-bottom]{--padding-bottom: var(--ion-padding, 16px);padding-bottom:var(--ion-padding, 16px)}[padding-vertical]{--padding-top: var(--ion-padding, 16px);--padding-bottom: var(--ion-padding, 16px);padding-top:var(--ion-padding, 16px);padding-bottom:var(--ion-padding, 16px)}[padding-horizontal]{--padding-start: var(--ion-padding, 16px);--padding-end: var(--ion-padding, 16px);padding-left:var(--ion-padding, 16px);padding-right:var(--ion-padding, 16px)}[no-margin]{--margin-start: 0;--margin-end: 0;--margin-top: 0;--margin-bottom: 0;margin:0}[margin]{--margin-start: var(--ion-margin, 16px);--margin-end: var(--ion-margin, 16px);--margin-top: var(--ion-margin, 16px);--margin-bottom: var(--ion-margin, 16px);margin:var(--ion-margin, 16px)}[margin-top]{--margin-top: var(--ion-margin, 16px);margin-top:var(--ion-margin, 16px)}[margin-start]{--margin-start: var(--ion-margin, 16px);margin-left:var(--ion-margin, 16px)}[margin-end]{--margin-end: var(--ion-margin, 16px);margin-right:var(--ion-margin, 16px)}[margin-bottom]{--margin-bottom: var(--ion-margin, 16px);margin-bottom:var(--ion-margin, 16px)}[margin-vertical]{--margin-top: var(--ion-margin, 16px);--margin-bottom: var(--ion-margin, 16px);margin-top:var(--ion-margin, 16px);margin-bottom:var(--ion-margin, 16px)}[margin-horizontal]{--margin-start: var(--ion-margin, 16px);--margin-end: var(--ion-margin, 16px);margin-left:var(--ion-margin, 16px);margin-right:var(--ion-margin, 16px)}[float-left]{float:left !important}[float-right]{float:right !important}[float-start]{float:left !important}[float-end]{float:right !important}@media (min-width: 576px){[float-sm-left]{float:left !important}[float-sm-right]{float:right !important}[float-sm-start]{float:left !important}[float-sm-end]{float:right !important}}@media (min-width: 768px){[float-md-left]{float:left !important}[float-md-right]{float:right !important}[float-md-start]{float:left !important}[float-md-end]{float:right !important}}@media (min-width: 992px){[float-lg-left]{float:left !important}[float-lg-right]{float:right !important}[float-lg-start]{float:left !important}[float-lg-end]{float:right !important}}@media (min-width: 1200px){[float-xl-left]{float:left !important}[float-xl-right]{float:right !important}[float-xl-start]{float:left !important}[float-xl-end]{float:right !important}}[text-center]{text-align:center !important}[text-justify]{text-align:justify !important}[text-start]{text-align:start !important}[text-end]{text-align:end !important}[text-left]{text-align:left !important}[text-right]{text-align:right !important}[text-nowrap]{white-space:nowrap !important}[text-wrap]{white-space:normal !important}@media (min-width: 576px){[text-sm-center]{text-align:center !important}[text-sm-justify]{text-align:justify !important}[text-sm-start]{text-align:start !important}[text-sm-end]{text-align:end !important}[text-sm-left]{text-align:left !important}[text-sm-right]{text-align:right !important}[text-sm-nowrap]{white-space:nowrap !important}[text-sm-wrap]{white-space:normal !important}}@media (min-width: 768px){[text-md-center]{text-align:center !important}[text-md-justify]{text-align:justify !important}[text-md-start]{text-align:start !important}[text-md-end]{text-align:end !important}[text-md-left]{text-align:left !important}[text-md-right]{text-align:right !important}[text-md-nowrap]{white-space:nowrap !important}[text-md-wrap]{white-space:normal !important}}@media (min-width: 992px){[text-lg-center]{text-align:center !important}[text-lg-justify]{text-align:justify !important}[text-lg-start]{text-align:start !important}[text-lg-end]{text-align:end !important}[text-lg-left]{text-align:left !important}[text-lg-right]{text-align:right !important}[text-lg-nowrap]{white-space:nowrap !important}[text-lg-wrap]{white-space:normal !important}}@media (min-width: 1200px){[text-xl-center]{text-align:center !important}[text-xl-justify]{text-align:justify !important}[text-xl-start]{text-align:start !important}[text-xl-end]{text-align:end !important}[text-xl-left]{text-align:left !important}[text-xl-right]{text-align:right !important}[text-xl-nowrap]{white-space:nowrap !important}[text-xl-wrap]{white-space:normal !important}}[text-uppercase]{text-transform:uppercase !important}[text-lowercase]{text-transform:lowercase !important}[text-capitalize]{text-transform:capitalize !important}@media (min-width: 576px){[text-sm-uppercase]{text-transform:uppercase !important}[text-sm-lowercase]{text-transform:lowercase !important}[text-sm-capitalize]{text-transform:capitalize !important}}@media (min-width: 768px){[text-md-uppercase]{text-transform:uppercase !important}[text-md-lowercase]{text-transform:lowercase !important}[text-md-capitalize]{text-transform:capitalize !important}}@media (min-width: 992px){[text-lg-uppercase]{text-transform:uppercase !important}[text-lg-lowercase]{text-transform:lowercase !important}[text-lg-capitalize]{text-transform:capitalize !important}}@media (min-width: 1200px){[text-xl-uppercase]{text-transform:uppercase !important}[text-xl-lowercase]{text-transform:lowercase !important}[text-xl-capitalize]{text-transform:capitalize !important}}[align-self-start]{align-self:flex-start !important}[align-self-end]{align-self:flex-end !important}[align-self-center]{align-self:center !important}[align-self-stretch]{align-self:stretch !important}[align-self-baseline]{align-self:baseline !important}[align-self-auto]{align-self:auto !important}[wrap]{flex-wrap:wrap !important}[nowrap]{flex-wrap:nowrap !important}[wrap-reverse]{flex-wrap:wrap-reverse !important}[justify-content-start]{justify-content:flex-start !important}[justify-content-center]{justify-content:center !important}[justify-content-end]{justify-content:flex-end !important}[justify-content-around]{justify-content:space-around !important}[justify-content-between]{justify-content:space-between !important}[justify-content-evenly]{justify-content:space-evenly !important}[align-items-start]{align-items:flex-start !important}[align-items-center]{align-items:center !important}[align-items-end]{align-items:flex-end !important}[align-items-stretch]{align-items:stretch !important}[align-items-baseline]{align-items:baseline !important}*{ font-family: 'Roboto', 'Lato', 'Raleway', 'Oswald', sans-serif; }.main{\r\n    display: grid;\r\n    grid-template-rows: 1fr 4fr;\r\n    overflow: hidden;\r\n    zoom: unset;\r\n}/* HEADER */.header{\r\n    display: grid;\r\n    grid-template-rows: 2fr 1fr ;\r\n}.menubar > div:nth-child(odd){ background: #222; }.menubar{\r\n    display: grid;\r\n    grid-template-columns: 1fr 14fr ;    \r\n}.top-menu > div:nth-child(odd){ background: #222; }.top-menu{\r\n    display: grid;\r\n    grid-template-rows: repeat(2, 1fr);\r\n}#toolbar, #lowerbar, #upperbar{ margin: 0; padding: 0; }/* SIDEBAR */.wrapper > #right_ws > #workspace{ background: white; padding: 1em; }.wrapper {\r\n    display: grid;\r\n    /* grid-template-columns: 100px auto; */\r\n    grid-template-columns: 0fr 1fr;\r\n    height: 100%;\r\n   \r\n}.showSymbolPanel { grid-template-columns: 100px auto; }#left_symbols {\r\n    float: left; \r\n    /* background-color: aqua; */\r\n    background-color: white;\r\n    display: block;\r\n    align-items: center;\r\n}#right_ws {\r\n    display: grid;\r\n    grid-template-rows: 5fr 1fr;\r\n    /* grid-template-columns: 1fr 5fr; */\r\n    grid-column-gap: 0.25em;\r\n    height: 100%;\r\n    overflow: auto;\r\n}.sidebar{ \r\n    background: white; \r\n    margin: 0; \r\n    display: grid;\r\n    grid-template-columns: 1.5fr 4fr;\r\n}.sideview{ padding: 0; height: 100%; }.tabs a{ \r\n    display: block;\r\n    background: #333333; \r\n    border-width: 0 0 5px;\r\n    border-style: solid;\r\n    border-color: rgba(187, 195, 199, 0.904);\r\n    color: #039be5;\r\n    padding: 10px;\r\n    text-decoration: none;\r\n    cursor: pointer; \r\n    text-align: center;\r\n}.tabs{ display: grid; grid-template-columns: repeat(3, 1fr); }.tabs a:hover{\r\n    color: #ddd;\r\n    background: #039be5;\r\n    border-width: 0 0 5px;\r\n    border-style: solid;\r\n    border-color: #333;\r\n}.tabs a.active-link {\r\n    color: #039be5;\r\n    border-width: 0 0 5px;\r\n    border-style: solid;\r\n    border-color: #039be5;\r\n    background: #ddd;\r\n}li a{ \r\n    display: block;\r\n    background: #A9B1B4; \r\n    color: #333;\r\n    padding: 10px;\r\n    margin: 0 10px;\r\n    text-decoration: none;\r\n    cursor: pointer; \r\n    text-align: center;\r\n}li a:hover{ color: #039be5; }#workspace > div{ margin: auto; }/* #workspace{ overflow: auto; } *//*** DROP-DOWN MENU [placeholder styles] ***/#lowerbar {\r\n    overflow: hidden;\r\n    background-color: #333;\r\n    font-family: Arial, Helvetica, sans-serif;\r\n}.dropdown {\r\n    float: left;\r\n    overflow: hidden;\r\n}.dropdown .dropbtn {\r\n    font-size: 12pt;    \r\n    border: none;\r\n    outline: none;\r\n    color: #F8F8F8;\r\n    padding: 14px 16px;\r\n    background-color: inherit;\r\n    font-family: inherit;\r\n    margin: 0;\r\n    display: block;\r\n}#lowerbar a:hover, .dropdown:hover .dropbtn {\r\n    background-color: #ddd;\r\n    color: #039be5;\r\n    cursor: pointer;\r\n}.dropdown-content {\r\n    display: none;\r\n    position: absolute;\r\n    background-color: #ddd;\r\n    min-width: 160px;\r\n    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);\r\n    z-index: 1;\r\n}.dropdown-content a {\r\n    float: none;\r\n    color: black;\r\n    padding: 12px 16px;\r\n    text-decoration: none;\r\n    display: block;\r\n    text-align: left;\r\n}.dropdown-content a:hover { background-color: #ddd; }.dropdown:hover .dropdown-content { display: block; }/*  SIDE MENU  */#sidemenu_list{\r\n    background-color: #333333;\r\n    color: #000000;\r\n}#sidemenu_list ion-item:hover{\r\n    background: #333;\r\n    /* color: #ddd; */\r\n    cursor: pointer;\r\n}#btn_newProject:hover { color: #54CBC9; }#btn_openProject:hover { color: #ffce00; }#btn_saveProject:hover { color: #4c8dff; }#btn_debugProgram:hover { color: #10dc60; }#btn_generateCode:hover { color: #AFF3CA; }#btn_clearWorkspace:hover { color: #f04141; }#btn_gettingStartedPage:hover, #btn_tutorialPage:hover,\r\n#btn_themePage:hover, #btn_aboutPage:hover,\r\n#btn_feedbackPage:hover, #btn_logOut:hover,\r\n#btn_goOnline:hover, #btn_backToWelcome:hover { color: #ddd; }textarea{ \r\n /* position: absolute;\r\n  justify-content: baseline;\r\n    width: 100%; padding: 5px; float: right; \r\n    background-color: #333;\r\n     \r\n    font-family: sans-serif; \r\n    resize: none; white-space: pre-wrap;Resize Edilme Açıla Bilir*/\r\n  }/* Symbol Pop Up (.popover-content)  Değişti 200 dü*/.symPopUp {\r\n  --width: 30px;\r\n /* --height: 500px; */\r\n}.symPopUp .popover-wrapper .popover-content {\r\n  /* top: 120px;\r\n  left: 600px; */\r\n margin: auto;\r\n  width: -webkit-fit-content;\r\n  width: -moz-fit-content;\r\n  width: fit-content;\r\n\r\n  /* height: 450px; */\r\n}/* Symbol Pop Up (.popover-content) */.symbolPromptAS {\r\n    width: -webkit-fit-content;\r\n    width: -moz-fit-content;\r\n    width: fit-content;\r\n  /* height: 450px; */\r\n  \r\n}.symbolPromptAS .popover-wrapper .popover-content {\r\n  /* top: 120px;\r\n  left: 600px; */\r\n  margin-left: 85px;\r\n  margin-top: 5px;\r\n  width: -webkit-fit-content;\r\n  width: -moz-fit-content;\r\n  width: fit-content;\r\n  \r\n /* overflow-x: scroll; */\r\n  /* height: 450px; */\r\n}/* Symbol Modal Textbox Focus */.dialogTextbox {\r\n    border: 2px solid rgb(248, 246, 246);\r\n    \r\n  }/* Clear Workspace Alert */.clearWS-yes { --background: #f04141; }.aalert_input{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n    font-size: 15px;\r\n    border-width: 45px;\r\n    border-color: black;\r\n    border-inline-start-color: black;\r\n}.alertTitle{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n    font-size: 20px;\r\n    color:crimson;\r\n    width: -webkit-fit-content;\r\n    width: -moz-fit-content;\r\n    width: fit-content;\r\n}.errorAlert{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n   color:crimson;\r\n   width: -webkit-fit-content;\r\n   width: -moz-fit-content;\r\n   width: fit-content;\r\n}.noerrorAlert{\r\n    font-family: sans-serif;\r\n    \r\n   color: white;\r\n}.errorWAlert{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n   color:gold;\r\n   width: -webkit-fit-content;\r\n   width: -moz-fit-content;\r\n   width: fit-content;\r\n}@media screen and (max-width: 768px) {\r\n    .aalert_input{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n    font-size: 15px;\r\n    border-width: 45px;\r\n    border-color: black;\r\n    border-inline-start-color: black;\r\n}\r\n.alertTitle{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n    font-size: 20px;\r\n    color:crimson;\r\n}\r\n.errorAlert{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n   color:crimson;\r\n   font-size: 12px;\r\n   word-wrap: normal;\r\n   width: -webkit-fit-content;\r\n   width: -moz-fit-content;\r\n   width: fit-content;\r\n}\r\n.noerrorAlert{\r\n    font-family: sans-serif;\r\n    font-size: 12px;\r\n   color: white;\r\n   font-weight: bold;\r\n}\r\n.errorWAlert{\r\n    font-family: sans-serif;\r\n    font-weight: bold;\r\n   color:gold;\r\n   font-size: 12px;\r\n   word-wrap: normal;\r\n   width: -webkit-fit-content;\r\n   width: -moz-fit-content;\r\n   width: fit-content;\r\n}\r\n}@media only screen and (max-width: 600px) {\r\n    .aalert_input{\r\n        font-family: sans-serif;\r\n        font-weight: bold;\r\n        font-size: 13px;\r\n        border-width: 45px;\r\n        border-color: black;\r\n        border-inline-start-color: black;\r\n    }\r\n    .alertTitle{\r\n        font-family: sans-serif;\r\n        font-weight: bold;\r\n        font-size: 13px;\r\n        color:crimson;\r\n    }\r\n    .errorAlert{\r\n        font-family: sans-serif;\r\n        font-weight: bold;\r\n       color:crimson;\r\n       font-size: 12px;\r\n       word-wrap: normal;\r\n       width: -webkit-fit-content;\r\n       width: -moz-fit-content;\r\n       width: fit-content;\r\n    }\r\n    .noerrorAlert{\r\n        font-family: sans-serif;\r\n        font-size: 12px;\r\n       color: white;\r\n       font-weight: bold;\r\n       width: -webkit-fit-content;\r\n       width: -moz-fit-content;\r\n       width: fit-content;\r\n       overflow-x: scroll;\r\n    }\r\n    .errorWAlert{\r\n        font-family: sans-serif;\r\n        font-weight: bold;\r\n       color:gold;\r\n       font-size: 12px;\r\n       word-wrap: normal;\r\n       width: -webkit-fit-content;\r\n       width: -moz-fit-content;\r\n       width: fit-content;\r\n       overflow-x: scroll;\r\n    }\r\n}/* ----Dragula CSS---- *//* in-flight clone */.gu-mirror {\n  position: fixed !important;\n  margin: 0 !important;\n  z-index: 9999 !important;\n  opacity: 0.8;\n  -ms-filter: \"progid:DXImageTransform.Microsoft.Alpha(Opacity=80)\";\n  filter: alpha(opacity=80);\n  pointer-events: none; }/* high-performance display:none; helper */.gu-hide {\n  left: -9999px !important; }/* added to mirrorContainer (default = body) while dragging */.gu-unselectable {\n  -webkit-user-select: none !important;\n  -moz-user-select: none !important;\n  -ms-user-select: none !important;\n  user-select: none !important;\n  cursor: -webkit-grabbing;\n  cursor: grabbing; }/* added to the source element while its mirror is dragged */.gu-transit {\n  opacity: 0.2;\n  -ms-filter: \"progid:DXImageTransform.Microsoft.Alpha(Opacity=20)\";\n  filter: alpha(opacity=20); }\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9AaW9uaWMvYW5ndWxhci9jc3MvY29yZS5jc3MiLCJub2RlX21vZHVsZXMvQGlvbmljL2FuZ3VsYXIvY3NzL25vcm1hbGl6ZS5jc3MiLCJub2RlX21vZHVsZXMvQGlvbmljL2FuZ3VsYXIvY3NzL3N0cnVjdHVyZS5jc3MiLCJub2RlX21vZHVsZXMvQGlvbmljL2FuZ3VsYXIvY3NzL3R5cG9ncmFwaHkuY3NzIiwibm9kZV9tb2R1bGVzL0Bpb25pYy9hbmd1bGFyL2Nzcy9wYWRkaW5nLmNzcyIsIm5vZGVfbW9kdWxlcy9AaW9uaWMvYW5ndWxhci9jc3MvZmxvYXQtZWxlbWVudHMuY3NzIiwibm9kZV9tb2R1bGVzL0Bpb25pYy9hbmd1bGFyL2Nzcy90ZXh0LWFsaWdubWVudC5jc3MiLCJub2RlX21vZHVsZXMvQGlvbmljL2FuZ3VsYXIvY3NzL3RleHQtdHJhbnNmb3JtYXRpb24uY3NzIiwibm9kZV9tb2R1bGVzL0Bpb25pYy9hbmd1bGFyL2Nzcy9mbGV4LXV0aWxzLmNzcyIsInNyYy9saWJyYXJpZXMvc3R5bGVzL21haW4uY3NzIiwic3JjL0M6XFxVc2Vyc1xcSGFzYW5fTW9uc3RlclxcQ0hBUC9zcmNcXGxpYnJhcmllc1xcc3R5bGVzXFxzeW1ib2xzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyw2RkFBNkYsQ0FBQyxRQUFRLDBEQUEwRCxDQUFDLEtBQUssMENBQTBDLENBQUMsd0JBQXdCLGVBQWUsQ0FBQyxtQkFBbUIsK0RBQStELDBFQUEwRSx5RUFBeUUsd0ZBQXdGLHNFQUFzRSxtRUFBbUUsQ0FBQyxxQkFBcUIsaUVBQWlFLDRFQUE0RSwyRUFBMkUsMEZBQTBGLHdFQUF3RSxxRUFBcUUsQ0FBQyxvQkFBb0IsZ0VBQWdFLDJFQUEyRSwwRUFBMEUseUZBQXlGLHVFQUF1RSxvRUFBb0UsQ0FBQyxtQkFBbUIsK0RBQStELHlFQUF5RSx5RUFBeUUsd0ZBQXdGLHNFQUFzRSxtRUFBbUUsQ0FBQyxtQkFBbUIsK0RBQStELHlFQUF5RSx5RUFBeUUsd0ZBQXdGLHNFQUFzRSxtRUFBbUUsQ0FBQyxrQkFBa0IsOERBQThELHdFQUF3RSx3RUFBd0UsdUZBQXVGLHFFQUFxRSxrRUFBa0UsQ0FBQyxpQkFBaUIsNkRBQTZELHlFQUF5RSx1RUFBdUUsZ0ZBQWdGLG9FQUFvRSxpRUFBaUUsQ0FBQyxrQkFBa0IsOERBQThELDBFQUEwRSx3RUFBd0UsdUZBQXVGLHFFQUFxRSxrRUFBa0UsQ0FBQyxnQkFBZ0IsNERBQTRELHFFQUFxRSxzRUFBc0UscUZBQXFGLG1FQUFtRSxnRUFBZ0UsQ0FBQyxVQUFVLE9BQU8sUUFBUSxNQUFNLFNBQVMsYUFBYSxrQkFBa0Isc0JBQXNCLDhCQUE4QiwwQkFBMEIsZ0JBQWdCLFNBQVMsQ0FBQyxpU0FBaVMsdUJBQXVCLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyw2Q0FBNkMsNkJBQTZCLENBQUMsOEJBQThCLEtBQUssaURBQWlELENBQUMsQ0FBQyx1REFBdUQsS0FBSyxtREFBbUQseURBQXlELHFEQUFxRCxzREFBc0QsQ0FBQyxDQUFDLGtEQUFrRCxLQUFLLDhDQUE4QyxvREFBb0QsZ0RBQWdELGlEQUFpRCxDQUFDLENBQUMsQUNBcDVLLDRCQUE0Qix1QkFBdUIsQ0FBQyxzQkFBc0IsYUFBYSxRQUFRLENBQUMsU0FBUyxnQkFBZ0IsQ0FBQyxJQUFJLGVBQWUsUUFBUSxDQUFDLGVBQWUsZUFBZSxDQUFDLE9BQU8sZUFBZSxDQUFDLEdBQUcsV0FBVyxlQUFlLHNCQUFzQixDQUFDLElBQUksYUFBYSxDQUFDLGtCQUFrQixpQ0FBaUMsYUFBYSxDQUFDLDRCQUE0QixvQkFBb0Isa0JBQWtCLENBQUMsU0FBUyxjQUFjLFlBQVksYUFBYSxhQUFhLENBQUMsb0NBQXNCLGdCQUFnQixDQUFDLEFBQXZDLDJCQUFzQixnQkFBZ0IsQ0FBQyxBQUF2QyxnQ0FBc0IsZ0JBQWdCLENBQUMsQUFBdkMsc0JBQXNCLGdCQUFnQixDQUFDLDJCQUEyQixTQUFTLGFBQWEsYUFBYSxDQUFDLG1FQUFtRSxlQUFlLHlCQUF5QixDQUFDLHVNQUF1TSx5QkFBeUIsQ0FBQyw2QkFBNkIsbUJBQW1CLENBQUMsT0FBTyxTQUFTLGdCQUFnQixvQkFBb0IsbUJBQW1CLHFCQUFxQixjQUFjLG9CQUFvQixlQUFlLHlCQUF5QixDQUFDLFdBQVcsY0FBYyxDQUFDLGtEQUFrRCxjQUFjLENBQUMsaURBQWlELFVBQVUsUUFBUSxDQUFDLDJDQUEyQyxVQUFVLHFCQUFxQixDQUFDLGdHQUFnRyxXQUFXLENBQUMsbUdBQW1HLHVCQUF1QixDQUFDLE1BQU0seUJBQXlCLGdCQUFnQixDQUFDLE1BQU0sU0FBUyxDQUFDLEFDQWhuRCxFQUFFLHNCQUFzQiwwQ0FBMEMsd0NBQXdDLDBCQUEwQixDQUFDLEtBQUssV0FBVyxZQUFZLDhCQUFxQixBQUFyQiwyQkFBcUIsQUFBckIsMEJBQXFCLEFBQXJCLHFCQUFxQixDQUFDLEtBQUssa0NBQWtDLG1DQUFtQyxTQUFTLFVBQVUsZUFBZSxXQUFXLGVBQWUsWUFBWSxnQkFBZ0Isa0NBQWtDLGdCQUFnQiwwQkFBMEIsdUJBQXVCLHlCQUF5QixxQkFBcUIsMkJBQTJCLDhCQUFxQixBQUFyQiwyQkFBcUIsQUFBckIsMEJBQXFCLEFBQXJCLHFCQUFxQixDQUFDLEFDQTNoQixLQUFLLGtDQUFrQyxDQUFDLEVBQUUsNkJBQTZCLHVDQUF1QyxDQUFDLGtCQUFrQixnQkFBZ0IsbUJBQW1CLGdCQUFnQixlQUFlLENBQUMsR0FBRyxnQkFBZ0IsY0FBYyxDQUFDLEdBQUcsZ0JBQWdCLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLGFBQWEsQ0FBQyxRQUFRLGtCQUFrQixjQUFjLGNBQWMsdUJBQXVCLENBQUMsSUFBSSxTQUFTLENBQUMsSUFBSSxhQUFhLENBQUMsQUNBbGQsYUFBYSxtQkFBbUIsaUJBQWlCLGlCQUFpQixvQkFBb0IsU0FBUyxDQUFDLFVBQVUsMENBQTBDLHdDQUF3Qyx3Q0FBd0MsMkNBQTJDLGdDQUFnQyxDQUFDLGNBQWMsd0NBQXdDLG9DQUFvQyxDQUFDLGdCQUFnQiwwQ0FBMEMscUNBQXFDLENBQUMsY0FBYyx3Q0FBd0Msc0NBQXNDLENBQUMsaUJBQWlCLDJDQUEyQyx1Q0FBdUMsQ0FBQyxtQkFBbUIsd0NBQXdDLDJDQUEyQyxxQ0FBcUMsdUNBQXVDLENBQUMscUJBQXFCLDBDQUEwQyx3Q0FBd0Msc0NBQXNDLHNDQUFzQyxDQUFDLFlBQVksa0JBQWtCLGdCQUFnQixnQkFBZ0IsbUJBQW1CLFFBQVEsQ0FBQyxTQUFTLHdDQUF3QyxzQ0FBc0Msc0NBQXNDLHlDQUF5Qyw4QkFBOEIsQ0FBQyxhQUFhLHNDQUFzQyxrQ0FBa0MsQ0FBQyxlQUFlLHdDQUF3QyxtQ0FBbUMsQ0FBQyxhQUFhLHNDQUFzQyxvQ0FBb0MsQ0FBQyxnQkFBZ0IseUNBQXlDLHFDQUFxQyxDQUFDLGtCQUFrQixzQ0FBc0MseUNBQXlDLG1DQUFtQyxxQ0FBcUMsQ0FBQyxvQkFBb0Isd0NBQXdDLHNDQUFzQyxvQ0FBb0Msb0NBQW9DLENBQUMsQUNBLytELGFBQWEscUJBQXFCLENBQUMsY0FBYyxzQkFBc0IsQ0FBQyxjQUFjLHFCQUFxQixDQUFDLFlBQVksc0JBQXNCLENBQUMsMEJBQTBCLGdCQUFnQixxQkFBcUIsQ0FBQyxpQkFBaUIsc0JBQXNCLENBQUMsaUJBQWlCLHFCQUFxQixDQUFDLGVBQWUsc0JBQXNCLENBQUMsQ0FBQywwQkFBMEIsZ0JBQWdCLHFCQUFxQixDQUFDLGlCQUFpQixzQkFBc0IsQ0FBQyxpQkFBaUIscUJBQXFCLENBQUMsZUFBZSxzQkFBc0IsQ0FBQyxDQUFDLDBCQUEwQixnQkFBZ0IscUJBQXFCLENBQUMsaUJBQWlCLHNCQUFzQixDQUFDLGlCQUFpQixxQkFBcUIsQ0FBQyxlQUFlLHNCQUFzQixDQUFDLENBQUMsMkJBQTJCLGdCQUFnQixxQkFBcUIsQ0FBQyxpQkFBaUIsc0JBQXNCLENBQUMsaUJBQWlCLHFCQUFxQixDQUFDLGVBQWUsc0JBQXNCLENBQUMsQ0FBQyxBQ0F4MkIsY0FBYyw0QkFBNEIsQ0FBQyxlQUFlLDZCQUE2QixDQUFDLGFBQWEsMkJBQTJCLENBQUMsV0FBVyx5QkFBeUIsQ0FBQyxZQUFZLDBCQUEwQixDQUFDLGFBQWEsMkJBQTJCLENBQUMsY0FBYyw2QkFBNkIsQ0FBQyxZQUFZLDZCQUE2QixDQUFDLDBCQUEwQixpQkFBaUIsNEJBQTRCLENBQUMsa0JBQWtCLDZCQUE2QixDQUFDLGdCQUFnQiwyQkFBMkIsQ0FBQyxjQUFjLHlCQUF5QixDQUFDLGVBQWUsMEJBQTBCLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDLGlCQUFpQiw2QkFBNkIsQ0FBQyxlQUFlLDZCQUE2QixDQUFDLENBQUMsMEJBQTBCLGlCQUFpQiw0QkFBNEIsQ0FBQyxrQkFBa0IsNkJBQTZCLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDLGNBQWMseUJBQXlCLENBQUMsZUFBZSwwQkFBMEIsQ0FBQyxnQkFBZ0IsMkJBQTJCLENBQUMsaUJBQWlCLDZCQUE2QixDQUFDLGVBQWUsNkJBQTZCLENBQUMsQ0FBQywwQkFBMEIsaUJBQWlCLDRCQUE0QixDQUFDLGtCQUFrQiw2QkFBNkIsQ0FBQyxnQkFBZ0IsMkJBQTJCLENBQUMsY0FBYyx5QkFBeUIsQ0FBQyxlQUFlLDBCQUEwQixDQUFDLGdCQUFnQiwyQkFBMkIsQ0FBQyxpQkFBaUIsNkJBQTZCLENBQUMsZUFBZSw2QkFBNkIsQ0FBQyxDQUFDLDJCQUEyQixpQkFBaUIsNEJBQTRCLENBQUMsa0JBQWtCLDZCQUE2QixDQUFDLGdCQUFnQiwyQkFBMkIsQ0FBQyxjQUFjLHlCQUF5QixDQUFDLGVBQWUsMEJBQTBCLENBQUMsZ0JBQWdCLDJCQUEyQixDQUFDLGlCQUFpQiw2QkFBNkIsQ0FBQyxlQUFlLDZCQUE2QixDQUFDLENBQUMsQUNBejBELGlCQUFpQixtQ0FBbUMsQ0FBQyxpQkFBaUIsbUNBQW1DLENBQUMsa0JBQWtCLG9DQUFvQyxDQUFDLDBCQUEwQixvQkFBb0IsbUNBQW1DLENBQUMsb0JBQW9CLG1DQUFtQyxDQUFDLHFCQUFxQixvQ0FBb0MsQ0FBQyxDQUFDLDBCQUEwQixvQkFBb0IsbUNBQW1DLENBQUMsb0JBQW9CLG1DQUFtQyxDQUFDLHFCQUFxQixvQ0FBb0MsQ0FBQyxDQUFDLDBCQUEwQixvQkFBb0IsbUNBQW1DLENBQUMsb0JBQW9CLG1DQUFtQyxDQUFDLHFCQUFxQixvQ0FBb0MsQ0FBQyxDQUFDLDJCQUEyQixvQkFBb0IsbUNBQW1DLENBQUMsb0JBQW9CLG1DQUFtQyxDQUFDLHFCQUFxQixvQ0FBb0MsQ0FBQyxDQUFDLEFDQXQ3QixtQkFBbUIsZ0NBQWdDLENBQUMsaUJBQWlCLDhCQUE4QixDQUFDLG9CQUFvQiw0QkFBNEIsQ0FBQyxxQkFBcUIsNkJBQTZCLENBQUMsc0JBQXNCLDhCQUE4QixDQUFDLGtCQUFrQiwwQkFBMEIsQ0FBQyxPQUFPLHlCQUF5QixDQUFDLFNBQVMsMkJBQTJCLENBQUMsZUFBZSxpQ0FBaUMsQ0FBQyx3QkFBd0IscUNBQXFDLENBQUMseUJBQXlCLGlDQUFpQyxDQUFDLHNCQUFzQixtQ0FBbUMsQ0FBQyx5QkFBeUIsdUNBQXVDLENBQUMsMEJBQTBCLHdDQUF3QyxDQUFDLHlCQUF5Qix1Q0FBdUMsQ0FBQyxvQkFBb0IsaUNBQWlDLENBQUMscUJBQXFCLDZCQUE2QixDQUFDLGtCQUFrQiwrQkFBK0IsQ0FBQyxzQkFBc0IsOEJBQThCLENBQUMsdUJBQXVCLCtCQUErQixDQUFDLEFDQWhpQyxHQUFHLCtEQUErRCxFQUFFLEFBRXBFO0lBQ0ksY0FBYztJQUNkLDRCQUE0QjtJQUM1QixpQkFBaUI7SUFDakIsWUFBWTtDQUNmLEFBRUQsWUFBWSxBQUNaO0lBQ0ksY0FBYztJQUNkLDZCQUE2QjtDQUNoQyxBQUNELCtCQUErQixpQkFBaUIsRUFBRSxBQUNsRDtJQUNJLGNBQWM7SUFDZCxpQ0FBaUM7Q0FDcEMsQUFDRCxnQ0FBZ0MsaUJBQWlCLEVBQUUsQUFDbkQ7SUFDSSxjQUFjO0lBQ2QsbUNBQW1DO0NBQ3RDLEFBR0QsZ0NBQWdDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQUFFeEQsYUFBYSxBQUNiLG1DQUFtQyxrQkFBa0IsQ0FBQyxhQUFhLEVBQUUsQUFDckU7SUFDSSxjQUFjO0lBQ2Qsd0NBQXdDO0lBQ3hDLCtCQUErQjtJQUMvQixhQUFhOztDQUVoQixBQUNELG1CQUFtQixrQ0FBa0MsRUFBRSxBQUN2RDtJQUNJLFlBQVk7SUFDWiw2QkFBNkI7SUFDN0Isd0JBQXdCO0lBQ3hCLGVBQWU7SUFDZixvQkFBb0I7Q0FDdkIsQUFDRDtJQUNJLGNBQWM7SUFDZCw0QkFBNEI7SUFDNUIscUNBQXFDO0lBQ3JDLHdCQUF3QjtJQUN4QixhQUFhO0lBQ2IsZUFBZTtDQUNsQixBQUNEO0lBQ0ksa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixjQUFjO0lBQ2QsaUNBQWlDO0NBQ3BDLEFBQ0QsV0FBVyxXQUFXLENBQUMsYUFBYSxFQUFFLEFBQ3RDO0lBQ0ksZUFBZTtJQUNmLG9CQUFvQjtJQUNwQixzQkFBc0I7SUFDdEIsb0JBQW9CO0lBQ3BCLHlDQUF5QztJQUN6QyxlQUFlO0lBQ2YsY0FBYztJQUNkLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsbUJBQW1CO0NBQ3RCLEFBQ0QsT0FBTyxjQUFjLENBQUMsc0NBQXNDLEVBQUUsQUFDOUQ7SUFDSSxZQUFZO0lBQ1osb0JBQW9CO0lBQ3BCLHNCQUFzQjtJQUN0QixvQkFBb0I7SUFDcEIsbUJBQW1CO0NBQ3RCLEFBQ0Q7SUFDSSxlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLG9CQUFvQjtJQUNwQixzQkFBc0I7SUFDdEIsaUJBQWlCO0NBQ3BCLEFBQ0Q7SUFDSSxlQUFlO0lBQ2Ysb0JBQW9CO0lBQ3BCLFlBQVk7SUFDWixjQUFjO0lBQ2QsZUFBZTtJQUNmLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsbUJBQW1CO0NBQ3RCLEFBQ0QsWUFBWSxlQUFlLEVBQUUsQUFDN0Isa0JBQWtCLGFBQWEsRUFBRSxBQUNqQyxtQ0FBbUMsQUFFbkMsNkNBQTZDLEFBQzdDO0lBQ0ksaUJBQWlCO0lBQ2pCLHVCQUF1QjtJQUN2QiwwQ0FBMEM7Q0FDN0MsQUFDRDtJQUNJLFlBQVk7SUFDWixpQkFBaUI7Q0FDcEIsQUFDRDtJQUNJLGdCQUFnQjtJQUNoQixhQUFhO0lBQ2IsY0FBYztJQUNkLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsMEJBQTBCO0lBQzFCLHFCQUFxQjtJQUNyQixVQUFVO0lBQ1YsZUFBZTtDQUNsQixBQUNEO0lBQ0ksdUJBQXVCO0lBQ3ZCLGVBQWU7SUFDZixnQkFBZ0I7Q0FDbkIsQUFDRDtJQUNJLGNBQWM7SUFDZCxtQkFBbUI7SUFDbkIsdUJBQXVCO0lBQ3ZCLGlCQUFpQjtJQUNqQiw2Q0FBNkM7SUFDN0MsV0FBVztDQUNkLEFBQ0Q7SUFDSSxZQUFZO0lBQ1osYUFBYTtJQUNiLG1CQUFtQjtJQUNuQixzQkFBc0I7SUFDdEIsZUFBZTtJQUNmLGlCQUFpQjtDQUNwQixBQUNELDRCQUE0Qix1QkFBdUIsRUFBRSxBQUNyRCxvQ0FBb0MsZUFBZSxFQUFFLEFBRXJELGlCQUFpQixBQUNqQjtJQUNJLDBCQUEwQjtJQUMxQixlQUFlO0NBQ2xCLEFBQ0Q7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtDQUNuQixBQUNELHdCQUF3QixlQUFlLEVBQUUsQUFDekMseUJBQXlCLGVBQWUsRUFBRSxBQUMxQyx5QkFBeUIsZUFBZSxFQUFFLEFBQzFDLDBCQUEwQixlQUFlLEVBQUUsQUFDM0MsMEJBQTBCLGVBQWUsRUFBRSxBQUMzQyw0QkFBNEIsZUFBZSxFQUFFLEFBQzdDOzs7Z0RBR2dELFlBQVksRUFBRSxBQUU5RDtDQUNDOzs7Ozs7bUVBTWtFO0dBQ2hFLEFBRUgscURBQXFELEFBQ3JEO0VBQ0UsY0FBYztDQUNmLHNCQUFzQjtDQUN0QixBQUVEO0VBQ0U7aUJBQ2U7Q0FDaEIsYUFBYTtFQUNaLDJCQUFtQjtFQUFuQix3QkFBbUI7RUFBbkIsbUJBQW1COztFQUVuQixvQkFBb0I7Q0FDckIsQUFFRCxzQ0FBc0MsQUFDdEM7SUFDSSwyQkFBbUI7SUFBbkIsd0JBQW1CO0lBQW5CLG1CQUFtQjtFQUNyQixvQkFBb0I7O0NBRXJCLEFBRUQ7RUFDRTtpQkFDZTtFQUNmLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsMkJBQW1CO0VBQW5CLHdCQUFtQjtFQUFuQixtQkFBbUI7O0NBRXBCLHlCQUF5QjtFQUN4QixvQkFBb0I7Q0FDckIsQUFFRCxnQ0FBZ0MsQUFDaEM7SUFDSSxxQ0FBcUM7O0dBRXRDLEFBRUgsMkJBQTJCLEFBQzNCLGVBQWUsc0JBQXNCLEVBQUUsQUFFdkM7SUFDSSx3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLGlDQUFpQztDQUNwQyxBQUNEO0lBQ0ksd0JBQXdCO0lBQ3hCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLDJCQUFtQjtJQUFuQix3QkFBbUI7SUFBbkIsbUJBQW1CO0NBQ3RCLEFBQ0Q7SUFDSSx3QkFBd0I7SUFDeEIsa0JBQWtCO0dBQ25CLGNBQWM7R0FDZCwyQkFBbUI7R0FBbkIsd0JBQW1CO0dBQW5CLG1CQUFtQjtDQUNyQixBQUNEO0lBQ0ksd0JBQXdCOztHQUV6QixhQUFhO0NBQ2YsQUFDRDtJQUNJLHdCQUF3QjtJQUN4QixrQkFBa0I7R0FDbkIsV0FBVztHQUNYLDJCQUFtQjtHQUFuQix3QkFBbUI7R0FBbkIsbUJBQW1CO0NBQ3JCLEFBQ0Q7SUFDSTtJQUNBLHdCQUF3QjtJQUN4QixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLG1CQUFtQjtJQUNuQixvQkFBb0I7SUFDcEIsaUNBQWlDO0NBQ3BDO0FBQ0Q7SUFDSSx3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLGdCQUFnQjtJQUNoQixjQUFjO0NBQ2pCO0FBQ0Q7SUFDSSx3QkFBd0I7SUFDeEIsa0JBQWtCO0dBQ25CLGNBQWM7R0FDZCxnQkFBZ0I7R0FDaEIsa0JBQWtCO0dBQ2xCLDJCQUFtQjtHQUFuQix3QkFBbUI7R0FBbkIsbUJBQW1CO0NBQ3JCO0FBQ0Q7SUFDSSx3QkFBd0I7SUFDeEIsZ0JBQWdCO0dBQ2pCLGFBQWE7R0FDYixrQkFBa0I7Q0FDcEI7QUFDRDtJQUNJLHdCQUF3QjtJQUN4QixrQkFBa0I7R0FDbkIsV0FBVztHQUNYLGdCQUFnQjtHQUNoQixrQkFBa0I7R0FDbEIsMkJBQW1CO0dBQW5CLHdCQUFtQjtHQUFuQixtQkFBbUI7Q0FDckI7Q0FDQSxBQUNEO0lBQ0k7UUFDSSx3QkFBd0I7UUFDeEIsa0JBQWtCO1FBQ2xCLGdCQUFnQjtRQUNoQixtQkFBbUI7UUFDbkIsb0JBQW9CO1FBQ3BCLGlDQUFpQztLQUNwQztJQUNEO1FBQ0ksd0JBQXdCO1FBQ3hCLGtCQUFrQjtRQUNsQixnQkFBZ0I7UUFDaEIsY0FBYztLQUNqQjtJQUNEO1FBQ0ksd0JBQXdCO1FBQ3hCLGtCQUFrQjtPQUNuQixjQUFjO09BQ2QsZ0JBQWdCO09BQ2hCLGtCQUFrQjtPQUNsQiwyQkFBbUI7T0FBbkIsd0JBQW1CO09BQW5CLG1CQUFtQjtLQUNyQjtJQUNEO1FBQ0ksd0JBQXdCO1FBQ3hCLGdCQUFnQjtPQUNqQixhQUFhO09BQ2Isa0JBQWtCO09BQ2xCLDJCQUFtQjtPQUFuQix3QkFBbUI7T0FBbkIsbUJBQW1CO09BQ25CLG1CQUFtQjtLQUNyQjtJQUNEO1FBQ0ksd0JBQXdCO1FBQ3hCLGtCQUFrQjtPQUNuQixXQUFXO09BQ1gsZ0JBQWdCO09BQ2hCLGtCQUFrQjtPQUNsQiwyQkFBbUI7T0FBbkIsd0JBQW1CO09BQW5CLG1CQUFtQjtPQUNuQixtQkFBbUI7S0FDckI7Q0FDSixBQ3pVRCx5QkFBeUIsQUFFekIscUJBQXFCLEFBQ3JCO0VBQ0UsMkJBQTBCO0VBQzFCLHFCQUFvQjtFQUNwQix5QkFBd0I7RUFDeEIsYUFBWTtFQUNaLGtFQUFpRTtFQUNqRSwwQkFBeUI7RUFDekIscUJBQW9CLEVBQ3JCLEFBRUQsMkNBQTJDLEFBQzNDO0VBQ0UseUJBQXdCLEVBQ3pCLEFBRUQsOERBQThELEFBQzlEO0VBQ0UscUNBQW9DO0VBQ3BDLGtDQUFpQztFQUNqQyxpQ0FBZ0M7RUFDaEMsNkJBQTRCO0VBQzVCLHlCQUF3QjtFQUN4QixpQkFBZ0IsRUFDakIsQUFFRCw2REFBNkQsQUFDN0Q7RUFDRSxhQUFZO0VBQ1osa0VBQWlFO0VBQ2pFLDBCQUF5QixFQUUxQiIsImZpbGUiOiJzcmMvZ2xvYmFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJodG1sLmlvc3stLWlvbi1kZWZhdWx0LWZvbnQ6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIlJvYm90b1wiLCBzYW5zLXNlcmlmfWh0bWwubWR7LS1pb24tZGVmYXVsdC1mb250OiBcIlJvYm90b1wiLCBcIkhlbHZldGljYSBOZXVlXCIsIHNhbnMtc2VyaWZ9aHRtbHstLWlvbi1mb250LWZhbWlseTogdmFyKC0taW9uLWRlZmF1bHQtZm9udCl9Ym9keS5iYWNrZHJvcC1uby1zY3JvbGx7b3ZlcmZsb3c6aGlkZGVufS5pb24tY29sb3ItcHJpbWFyeXstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSwgIzM4ODBmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiLCA1NiwxMjgsMjU1KSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0LXJnYiwgMjU1LDI1NSwyNTUpICFpbXBvcnRhbnQ7LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlLCAjMzE3MWUwKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQsICM0YzhkZmYpICFpbXBvcnRhbnR9Lmlvbi1jb2xvci1zZWNvbmRhcnl7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSwgIzBjZDFlOCkgIWltcG9ydGFudDstLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeS1yZ2IsIDEyLDIwOSwyMzIpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktY29udHJhc3QsICNmZmYpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5LWNvbnRyYXN0LXJnYiwgMjU1LDI1NSwyNTUpICFpbXBvcnRhbnQ7LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktc2hhZGUsICMwYmI4Y2MpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItdGludDogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeS10aW50LCAjMjRkNmVhKSAhaW1wb3J0YW50fS5pb24tY29sb3ItdGVydGlhcnl7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LCAjNzA0NGZmKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktcmdiLCAxMTIsNjgsMjU1KSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QsICNmZmYpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QtcmdiLCAyNTUsMjU1LDI1NSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5LXNoYWRlLCAjNjMzY2UwKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeS10aW50LCAjN2U1N2ZmKSAhaW1wb3J0YW50fS5pb24tY29sb3Itc3VjY2Vzc3stLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3Itc3VjY2VzcywgIzEwZGM2MCkgIWltcG9ydGFudDstLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MtcmdiLCAxNiwyMjAsOTYpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItY29udHJhc3Q6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzLWNvbnRyYXN0LCAjZmZmKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0LXJnYjogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MtY29udHJhc3QtcmdiLCAyNTUsMjU1LDI1NSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3Mtc2hhZGUsICMwZWMyNTQpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItdGludDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MtdGludCwgIzI4ZTA3MCkgIWltcG9ydGFudH0uaW9uLWNvbG9yLXdhcm5pbmd7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcsICNmZmNlMDApICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLXJnYiwgMjU1LDIwNiwwKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3Itd2FybmluZy1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLWNvbnRyYXN0LXJnYiwgMjU1LDI1NSwyNTUpICFpbXBvcnRhbnQ7LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLXNoYWRlLCAjZTBiNTAwKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLXRpbnQsICNmZmQzMWEpICFpbXBvcnRhbnR9Lmlvbi1jb2xvci1kYW5nZXJ7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLWRhbmdlciwgI2YwNDE0MSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1iYXNlLXJnYjogdmFyKC0taW9uLWNvbG9yLWRhbmdlci1yZ2IsIDI0MCw2NSw2NSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0taW9uLWNvbG9yLWRhbmdlci1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXItY29udHJhc3QtcmdiLCAyNTUsMjU1LDI1NSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLWRhbmdlci1zaGFkZSwgI2QzMzkzOSkgIWltcG9ydGFudDstLWlvbi1jb2xvci10aW50OiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyLXRpbnQsICNmMjU0NTQpICFpbXBvcnRhbnR9Lmlvbi1jb2xvci1saWdodHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItbGlnaHQsICNmNGY1ZjgpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLWlvbi1jb2xvci1saWdodC1yZ2IsIDI0NCwyNDUsMjQ4KSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3ItbGlnaHQtY29udHJhc3QsICMwMDApICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtY29udHJhc3QtcmdiLCAwLDAsMCkgIWltcG9ydGFudDstLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlLCAjZDdkOGRhKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50LCAjZjVmNmY5KSAhaW1wb3J0YW50fS5pb24tY29sb3ItbWVkaXVtey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0sICM5ODlhYTIpICFpbXBvcnRhbnQ7LS1pb24tY29sb3ItYmFzZS1yZ2I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tcmdiLCAxNTIsMTU0LDE2MikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QtcmdiLCAyNTUsMjU1LDI1NSkgIWltcG9ydGFudDstLWlvbi1jb2xvci1zaGFkZTogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSwgIzg2ODg4ZikgIWltcG9ydGFudDstLWlvbi1jb2xvci10aW50OiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQsICNhMmE0YWIpICFpbXBvcnRhbnR9Lmlvbi1jb2xvci1kYXJrey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1kYXJrLCAjMjIyNDI4KSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1pb24tY29sb3ItZGFyay1yZ2IsIDM0LDM2LDQwKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLWNvbnRyYXN0OiB2YXIoLS1pb24tY29sb3ItZGFyay1jb250cmFzdCwgI2ZmZikgIWltcG9ydGFudDstLWlvbi1jb2xvci1jb250cmFzdC1yZ2I6IHZhcigtLWlvbi1jb2xvci1kYXJrLWNvbnRyYXN0LXJnYiwgMjU1LDI1NSwyNTUpICFpbXBvcnRhbnQ7LS1pb24tY29sb3Itc2hhZGU6IHZhcigtLWlvbi1jb2xvci1kYXJrLXNoYWRlLCAjMWUyMDIzKSAhaW1wb3J0YW50Oy0taW9uLWNvbG9yLXRpbnQ6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQsICMzODNhM2UpICFpbXBvcnRhbnR9Lmlvbi1wYWdle2xlZnQ6MDtyaWdodDowO3RvcDowO2JvdHRvbTowO2Rpc3BsYXk6ZmxleDtwb3NpdGlvbjphYnNvbHV0ZTtmbGV4LWRpcmVjdGlvbjpjb2x1bW47anVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47Y29udGFpbjpsYXlvdXQgc2l6ZSBzdHlsZTtvdmVyZmxvdzpoaWRkZW47ei1pbmRleDowfWlvbi1yb3V0ZSxpb24tcm91dGUtcmVkaXJlY3QsaW9uLXJvdXRlcixpb24tYW5pbWF0aW9uLWNvbnRyb2xsZXIsaW9uLW5hdi1jb250cm9sbGVyLGlvbi1tZW51LWNvbnRyb2xsZXIsaW9uLWFjdGlvbi1zaGVldC1jb250cm9sbGVyLGlvbi1hbGVydC1jb250cm9sbGVyLGlvbi1sb2FkaW5nLWNvbnRyb2xsZXIsaW9uLW1vZGFsLWNvbnRyb2xsZXIsaW9uLXBpY2tlci1jb250cm9sbGVyLGlvbi1wb3BvdmVyLWNvbnRyb2xsZXIsaW9uLXRvYXN0LWNvbnRyb2xsZXIsLmlvbi1wYWdlLWhpZGRlbixbaGlkZGVuXXtkaXNwbGF5Om5vbmUgIWltcG9ydGFudH0uaW9uLXBhZ2UtaW52aXNpYmxle29wYWNpdHk6MH1odG1sLnBsdC1pb3MucGx0LWh5YnJpZCxodG1sLnBsdC1pb3MucGx0LXB3YXstLWlvbi1zdGF0dXNiYXItcGFkZGluZzogMjBweH1Ac3VwcG9ydHMgKHBhZGRpbmctdG9wOiAyMHB4KXtodG1sey0taW9uLXNhZmUtYXJlYS10b3A6IHZhcigtLWlvbi1zdGF0dXNiYXItcGFkZGluZyl9fUBzdXBwb3J0cyAocGFkZGluZy10b3A6IGNvbnN0YW50KHNhZmUtYXJlYS1pbnNldC10b3ApKXtodG1sey0taW9uLXNhZmUtYXJlYS10b3A6IGNvbnN0YW50KHNhZmUtYXJlYS1pbnNldC10b3ApOy0taW9uLXNhZmUtYXJlYS1ib3R0b206IGNvbnN0YW50KHNhZmUtYXJlYS1pbnNldC1ib3R0b20pOy0taW9uLXNhZmUtYXJlYS1sZWZ0OiBjb25zdGFudChzYWZlLWFyZWEtaW5zZXQtbGVmdCk7LS1pb24tc2FmZS1hcmVhLXJpZ2h0OiBjb25zdGFudChzYWZlLWFyZWEtaW5zZXQtcmlnaHQpfX1Ac3VwcG9ydHMgKHBhZGRpbmctdG9wOiBlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCkpe2h0bWx7LS1pb24tc2FmZS1hcmVhLXRvcDogZW52KHNhZmUtYXJlYS1pbnNldC10b3ApOy0taW9uLXNhZmUtYXJlYS1ib3R0b206IGVudihzYWZlLWFyZWEtaW5zZXQtYm90dG9tKTstLWlvbi1zYWZlLWFyZWEtbGVmdDogZW52KHNhZmUtYXJlYS1pbnNldC1sZWZ0KTstLWlvbi1zYWZlLWFyZWEtcmlnaHQ6IGVudihzYWZlLWFyZWEtaW5zZXQtcmlnaHQpfX1cbiIsImF1ZGlvLGNhbnZhcyxwcm9ncmVzcyx2aWRlb3t2ZXJ0aWNhbC1hbGlnbjpiYXNlbGluZX1hdWRpbzpub3QoW2NvbnRyb2xzXSl7ZGlzcGxheTpub25lO2hlaWdodDowfWIsc3Ryb25ne2ZvbnQtd2VpZ2h0OmJvbGR9aW1ne21heC13aWR0aDoxMDAlO2JvcmRlcjowfXN2Zzpub3QoOnJvb3Qpe292ZXJmbG93OmhpZGRlbn1maWd1cmV7bWFyZ2luOjFlbSA0MHB4fWhye2hlaWdodDoxcHg7Ym9yZGVyLXdpZHRoOjA7Ym94LXNpemluZzpjb250ZW50LWJveH1wcmV7b3ZlcmZsb3c6YXV0b31jb2RlLGtiZCxwcmUsc2FtcHtmb250LWZhbWlseTptb25vc3BhY2UsIG1vbm9zcGFjZTtmb250LXNpemU6MWVtfWxhYmVsLGlucHV0LHNlbGVjdCx0ZXh0YXJlYXtmb250LWZhbWlseTppbmhlcml0O2xpbmUtaGVpZ2h0Om5vcm1hbH10ZXh0YXJlYXtvdmVyZmxvdzphdXRvO2hlaWdodDphdXRvO2ZvbnQ6aW5oZXJpdDtjb2xvcjppbmhlcml0fXRleHRhcmVhOjpwbGFjZWhvbGRlcntwYWRkaW5nLWxlZnQ6MnB4fWZvcm0saW5wdXQsb3B0Z3JvdXAsc2VsZWN0e21hcmdpbjowO2ZvbnQ6aW5oZXJpdDtjb2xvcjppbmhlcml0fWh0bWwgaW5wdXRbdHlwZT1cImJ1dHRvblwiXSxpbnB1dFt0eXBlPVwicmVzZXRcIl0saW5wdXRbdHlwZT1cInN1Ym1pdFwiXXtjdXJzb3I6cG9pbnRlcjstd2Via2l0LWFwcGVhcmFuY2U6YnV0dG9ufWEsYSBkaXYsYSBzcGFuLGEgaW9uLWljb24sYSBpb24tbGFiZWwsYnV0dG9uLGJ1dHRvbiBkaXYsYnV0dG9uIHNwYW4sYnV0dG9uIGlvbi1pY29uLGJ1dHRvbiBpb24tbGFiZWwsW3RhcHBhYmxlXSxbdGFwcGFibGVdIGRpdixbdGFwcGFibGVdIHNwYW4sW3RhcHBhYmxlXSBpb24taWNvbixbdGFwcGFibGVdIGlvbi1sYWJlbCxpbnB1dCx0ZXh0YXJlYXt0b3VjaC1hY3Rpb246bWFuaXB1bGF0aW9ufWEgaW9uLWxhYmVsLGJ1dHRvbiBpb24tbGFiZWx7cG9pbnRlci1ldmVudHM6bm9uZX1idXR0b257Ym9yZGVyOjA7Ym9yZGVyLXJhZGl1czowO2ZvbnQtZmFtaWx5OmluaGVyaXQ7Zm9udC1zdHlsZTppbmhlcml0O2ZvbnQtdmFyaWFudDppbmhlcml0O2xpbmUtaGVpZ2h0OjE7dGV4dC10cmFuc2Zvcm06bm9uZTtjdXJzb3I6cG9pbnRlcjstd2Via2l0LWFwcGVhcmFuY2U6YnV0dG9ufVt0YXBwYWJsZV17Y3Vyc29yOnBvaW50ZXJ9YVtkaXNhYmxlZF0sYnV0dG9uW2Rpc2FibGVkXSxodG1sIGlucHV0W2Rpc2FibGVkXXtjdXJzb3I6ZGVmYXVsdH1idXR0b246Oi1tb3otZm9jdXMtaW5uZXIsaW5wdXQ6Oi1tb3otZm9jdXMtaW5uZXJ7cGFkZGluZzowO2JvcmRlcjowfWlucHV0W3R5cGU9XCJjaGVja2JveFwiXSxpbnB1dFt0eXBlPVwicmFkaW9cIl17cGFkZGluZzowO2JveC1zaXppbmc6Ym9yZGVyLWJveH1pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLGlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b257aGVpZ2h0OmF1dG99aW5wdXRbdHlwZT1cInNlYXJjaFwiXTo6LXdlYmtpdC1zZWFyY2gtY2FuY2VsLWJ1dHRvbixpbnB1dFt0eXBlPVwic2VhcmNoXCJdOjotd2Via2l0LXNlYXJjaC1kZWNvcmF0aW9uey13ZWJraXQtYXBwZWFyYW5jZTpub25lfXRhYmxle2JvcmRlci1jb2xsYXBzZTpjb2xsYXBzZTtib3JkZXItc3BhY2luZzowfXRkLHRoe3BhZGRpbmc6MH1cbiIsIip7Ym94LXNpemluZzpib3JkZXItYm94Oy13ZWJraXQtdGFwLWhpZ2hsaWdodC1jb2xvcjpyZ2JhKDAsMCwwLDApOy13ZWJraXQtdGFwLWhpZ2hsaWdodC1jb2xvcjp0cmFuc3BhcmVudDstd2Via2l0LXRvdWNoLWNhbGxvdXQ6bm9uZX1odG1se3dpZHRoOjEwMCU7aGVpZ2h0OjEwMCU7dGV4dC1zaXplLWFkanVzdDoxMDAlfWJvZHl7LW1vei1vc3gtZm9udC1zbW9vdGhpbmc6Z3JheXNjYWxlOy13ZWJraXQtZm9udC1zbW9vdGhpbmc6YW50aWFsaWFzZWQ7bWFyZ2luOjA7cGFkZGluZzowO3Bvc2l0aW9uOmZpeGVkO3dpZHRoOjEwMCU7bWF4LXdpZHRoOjEwMCU7aGVpZ2h0OjEwMCU7bWF4LWhlaWdodDoxMDAlO3RleHQtcmVuZGVyaW5nOm9wdGltaXplTGVnaWJpbGl0eTtvdmVyZmxvdzpoaWRkZW47dG91Y2gtYWN0aW9uOm1hbmlwdWxhdGlvbjstd2Via2l0LXVzZXItZHJhZzpub25lOy1tcy1jb250ZW50LXpvb21pbmc6bm9uZTt3b3JkLXdyYXA6YnJlYWstd29yZDtvdmVyc2Nyb2xsLWJlaGF2aW9yLXk6bm9uZTt0ZXh0LXNpemUtYWRqdXN0Om5vbmV9XG4iLCJodG1se2ZvbnQtZmFtaWx5OnZhcigtLWlvbi1mb250LWZhbWlseSl9YXtiYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50O2NvbG9yOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5LCAjMzg4MGZmKX1oMSxoMixoMyxoNCxoNSxoNnttYXJnaW4tdG9wOjE2cHg7bWFyZ2luLWJvdHRvbToxMHB4O2ZvbnQtd2VpZ2h0OjUwMDtsaW5lLWhlaWdodDoxLjJ9aDF7bWFyZ2luLXRvcDoyMHB4O2ZvbnQtc2l6ZToyNnB4fWgye21hcmdpbi10b3A6MThweDtmb250LXNpemU6MjRweH1oM3tmb250LXNpemU6MjJweH1oNHtmb250LXNpemU6MjBweH1oNXtmb250LXNpemU6MThweH1oNntmb250LXNpemU6MTZweH1zbWFsbHtmb250LXNpemU6NzUlfXN1YixzdXB7cG9zaXRpb246cmVsYXRpdmU7Zm9udC1zaXplOjc1JTtsaW5lLWhlaWdodDowO3ZlcnRpY2FsLWFsaWduOmJhc2VsaW5lfXN1cHt0b3A6LS41ZW19c3Vie2JvdHRvbTotLjI1ZW19XG4iLCJbbm8tcGFkZGluZ117LS1wYWRkaW5nLXN0YXJ0OiAwOy0tcGFkZGluZy1lbmQ6IDA7LS1wYWRkaW5nLXRvcDogMDstLXBhZGRpbmctYm90dG9tOiAwO3BhZGRpbmc6MH1bcGFkZGluZ117LS1wYWRkaW5nLXN0YXJ0OiB2YXIoLS1pb24tcGFkZGluZywgMTZweCk7LS1wYWRkaW5nLWVuZDogdmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpOy0tcGFkZGluZy10b3A6IHZhcigtLWlvbi1wYWRkaW5nLCAxNnB4KTstLXBhZGRpbmctYm90dG9tOiB2YXIoLS1pb24tcGFkZGluZywgMTZweCk7cGFkZGluZzp2YXIoLS1pb24tcGFkZGluZywgMTZweCl9W3BhZGRpbmctdG9wXXstLXBhZGRpbmctdG9wOiB2YXIoLS1pb24tcGFkZGluZywgMTZweCk7cGFkZGluZy10b3A6dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpfVtwYWRkaW5nLXN0YXJ0XXstLXBhZGRpbmctc3RhcnQ6IHZhcigtLWlvbi1wYWRkaW5nLCAxNnB4KTtwYWRkaW5nLWxlZnQ6dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpfVtwYWRkaW5nLWVuZF17LS1wYWRkaW5nLWVuZDogdmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpO3BhZGRpbmctcmlnaHQ6dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpfVtwYWRkaW5nLWJvdHRvbV17LS1wYWRkaW5nLWJvdHRvbTogdmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpO3BhZGRpbmctYm90dG9tOnZhcigtLWlvbi1wYWRkaW5nLCAxNnB4KX1bcGFkZGluZy12ZXJ0aWNhbF17LS1wYWRkaW5nLXRvcDogdmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpOy0tcGFkZGluZy1ib3R0b206IHZhcigtLWlvbi1wYWRkaW5nLCAxNnB4KTtwYWRkaW5nLXRvcDp2YXIoLS1pb24tcGFkZGluZywgMTZweCk7cGFkZGluZy1ib3R0b206dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpfVtwYWRkaW5nLWhvcml6b250YWxdey0tcGFkZGluZy1zdGFydDogdmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpOy0tcGFkZGluZy1lbmQ6IHZhcigtLWlvbi1wYWRkaW5nLCAxNnB4KTtwYWRkaW5nLWxlZnQ6dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpO3BhZGRpbmctcmlnaHQ6dmFyKC0taW9uLXBhZGRpbmcsIDE2cHgpfVtuby1tYXJnaW5dey0tbWFyZ2luLXN0YXJ0OiAwOy0tbWFyZ2luLWVuZDogMDstLW1hcmdpbi10b3A6IDA7LS1tYXJnaW4tYm90dG9tOiAwO21hcmdpbjowfVttYXJnaW5dey0tbWFyZ2luLXN0YXJ0OiB2YXIoLS1pb24tbWFyZ2luLCAxNnB4KTstLW1hcmdpbi1lbmQ6IHZhcigtLWlvbi1tYXJnaW4sIDE2cHgpOy0tbWFyZ2luLXRvcDogdmFyKC0taW9uLW1hcmdpbiwgMTZweCk7LS1tYXJnaW4tYm90dG9tOiB2YXIoLS1pb24tbWFyZ2luLCAxNnB4KTttYXJnaW46dmFyKC0taW9uLW1hcmdpbiwgMTZweCl9W21hcmdpbi10b3Bdey0tbWFyZ2luLXRvcDogdmFyKC0taW9uLW1hcmdpbiwgMTZweCk7bWFyZ2luLXRvcDp2YXIoLS1pb24tbWFyZ2luLCAxNnB4KX1bbWFyZ2luLXN0YXJ0XXstLW1hcmdpbi1zdGFydDogdmFyKC0taW9uLW1hcmdpbiwgMTZweCk7bWFyZ2luLWxlZnQ6dmFyKC0taW9uLW1hcmdpbiwgMTZweCl9W21hcmdpbi1lbmRdey0tbWFyZ2luLWVuZDogdmFyKC0taW9uLW1hcmdpbiwgMTZweCk7bWFyZ2luLXJpZ2h0OnZhcigtLWlvbi1tYXJnaW4sIDE2cHgpfVttYXJnaW4tYm90dG9tXXstLW1hcmdpbi1ib3R0b206IHZhcigtLWlvbi1tYXJnaW4sIDE2cHgpO21hcmdpbi1ib3R0b206dmFyKC0taW9uLW1hcmdpbiwgMTZweCl9W21hcmdpbi12ZXJ0aWNhbF17LS1tYXJnaW4tdG9wOiB2YXIoLS1pb24tbWFyZ2luLCAxNnB4KTstLW1hcmdpbi1ib3R0b206IHZhcigtLWlvbi1tYXJnaW4sIDE2cHgpO21hcmdpbi10b3A6dmFyKC0taW9uLW1hcmdpbiwgMTZweCk7bWFyZ2luLWJvdHRvbTp2YXIoLS1pb24tbWFyZ2luLCAxNnB4KX1bbWFyZ2luLWhvcml6b250YWxdey0tbWFyZ2luLXN0YXJ0OiB2YXIoLS1pb24tbWFyZ2luLCAxNnB4KTstLW1hcmdpbi1lbmQ6IHZhcigtLWlvbi1tYXJnaW4sIDE2cHgpO21hcmdpbi1sZWZ0OnZhcigtLWlvbi1tYXJnaW4sIDE2cHgpO21hcmdpbi1yaWdodDp2YXIoLS1pb24tbWFyZ2luLCAxNnB4KX1cbiIsIltmbG9hdC1sZWZ0XXtmbG9hdDpsZWZ0ICFpbXBvcnRhbnR9W2Zsb2F0LXJpZ2h0XXtmbG9hdDpyaWdodCAhaW1wb3J0YW50fVtmbG9hdC1zdGFydF17ZmxvYXQ6bGVmdCAhaW1wb3J0YW50fVtmbG9hdC1lbmRde2Zsb2F0OnJpZ2h0ICFpbXBvcnRhbnR9QG1lZGlhIChtaW4td2lkdGg6IDU3NnB4KXtbZmxvYXQtc20tbGVmdF17ZmxvYXQ6bGVmdCAhaW1wb3J0YW50fVtmbG9hdC1zbS1yaWdodF17ZmxvYXQ6cmlnaHQgIWltcG9ydGFudH1bZmxvYXQtc20tc3RhcnRde2Zsb2F0OmxlZnQgIWltcG9ydGFudH1bZmxvYXQtc20tZW5kXXtmbG9hdDpyaWdodCAhaW1wb3J0YW50fX1AbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpe1tmbG9hdC1tZC1sZWZ0XXtmbG9hdDpsZWZ0ICFpbXBvcnRhbnR9W2Zsb2F0LW1kLXJpZ2h0XXtmbG9hdDpyaWdodCAhaW1wb3J0YW50fVtmbG9hdC1tZC1zdGFydF17ZmxvYXQ6bGVmdCAhaW1wb3J0YW50fVtmbG9hdC1tZC1lbmRde2Zsb2F0OnJpZ2h0ICFpbXBvcnRhbnR9fUBtZWRpYSAobWluLXdpZHRoOiA5OTJweCl7W2Zsb2F0LWxnLWxlZnRde2Zsb2F0OmxlZnQgIWltcG9ydGFudH1bZmxvYXQtbGctcmlnaHRde2Zsb2F0OnJpZ2h0ICFpbXBvcnRhbnR9W2Zsb2F0LWxnLXN0YXJ0XXtmbG9hdDpsZWZ0ICFpbXBvcnRhbnR9W2Zsb2F0LWxnLWVuZF17ZmxvYXQ6cmlnaHQgIWltcG9ydGFudH19QG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCl7W2Zsb2F0LXhsLWxlZnRde2Zsb2F0OmxlZnQgIWltcG9ydGFudH1bZmxvYXQteGwtcmlnaHRde2Zsb2F0OnJpZ2h0ICFpbXBvcnRhbnR9W2Zsb2F0LXhsLXN0YXJ0XXtmbG9hdDpsZWZ0ICFpbXBvcnRhbnR9W2Zsb2F0LXhsLWVuZF17ZmxvYXQ6cmlnaHQgIWltcG9ydGFudH19XG4iLCJbdGV4dC1jZW50ZXJde3RleHQtYWxpZ246Y2VudGVyICFpbXBvcnRhbnR9W3RleHQtanVzdGlmeV17dGV4dC1hbGlnbjpqdXN0aWZ5ICFpbXBvcnRhbnR9W3RleHQtc3RhcnRde3RleHQtYWxpZ246c3RhcnQgIWltcG9ydGFudH1bdGV4dC1lbmRde3RleHQtYWxpZ246ZW5kICFpbXBvcnRhbnR9W3RleHQtbGVmdF17dGV4dC1hbGlnbjpsZWZ0ICFpbXBvcnRhbnR9W3RleHQtcmlnaHRde3RleHQtYWxpZ246cmlnaHQgIWltcG9ydGFudH1bdGV4dC1ub3dyYXBde3doaXRlLXNwYWNlOm5vd3JhcCAhaW1wb3J0YW50fVt0ZXh0LXdyYXBde3doaXRlLXNwYWNlOm5vcm1hbCAhaW1wb3J0YW50fUBtZWRpYSAobWluLXdpZHRoOiA1NzZweCl7W3RleHQtc20tY2VudGVyXXt0ZXh0LWFsaWduOmNlbnRlciAhaW1wb3J0YW50fVt0ZXh0LXNtLWp1c3RpZnlde3RleHQtYWxpZ246anVzdGlmeSAhaW1wb3J0YW50fVt0ZXh0LXNtLXN0YXJ0XXt0ZXh0LWFsaWduOnN0YXJ0ICFpbXBvcnRhbnR9W3RleHQtc20tZW5kXXt0ZXh0LWFsaWduOmVuZCAhaW1wb3J0YW50fVt0ZXh0LXNtLWxlZnRde3RleHQtYWxpZ246bGVmdCAhaW1wb3J0YW50fVt0ZXh0LXNtLXJpZ2h0XXt0ZXh0LWFsaWduOnJpZ2h0ICFpbXBvcnRhbnR9W3RleHQtc20tbm93cmFwXXt3aGl0ZS1zcGFjZTpub3dyYXAgIWltcG9ydGFudH1bdGV4dC1zbS13cmFwXXt3aGl0ZS1zcGFjZTpub3JtYWwgIWltcG9ydGFudH19QG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KXtbdGV4dC1tZC1jZW50ZXJde3RleHQtYWxpZ246Y2VudGVyICFpbXBvcnRhbnR9W3RleHQtbWQtanVzdGlmeV17dGV4dC1hbGlnbjpqdXN0aWZ5ICFpbXBvcnRhbnR9W3RleHQtbWQtc3RhcnRde3RleHQtYWxpZ246c3RhcnQgIWltcG9ydGFudH1bdGV4dC1tZC1lbmRde3RleHQtYWxpZ246ZW5kICFpbXBvcnRhbnR9W3RleHQtbWQtbGVmdF17dGV4dC1hbGlnbjpsZWZ0ICFpbXBvcnRhbnR9W3RleHQtbWQtcmlnaHRde3RleHQtYWxpZ246cmlnaHQgIWltcG9ydGFudH1bdGV4dC1tZC1ub3dyYXBde3doaXRlLXNwYWNlOm5vd3JhcCAhaW1wb3J0YW50fVt0ZXh0LW1kLXdyYXBde3doaXRlLXNwYWNlOm5vcm1hbCAhaW1wb3J0YW50fX1AbWVkaWEgKG1pbi13aWR0aDogOTkycHgpe1t0ZXh0LWxnLWNlbnRlcl17dGV4dC1hbGlnbjpjZW50ZXIgIWltcG9ydGFudH1bdGV4dC1sZy1qdXN0aWZ5XXt0ZXh0LWFsaWduOmp1c3RpZnkgIWltcG9ydGFudH1bdGV4dC1sZy1zdGFydF17dGV4dC1hbGlnbjpzdGFydCAhaW1wb3J0YW50fVt0ZXh0LWxnLWVuZF17dGV4dC1hbGlnbjplbmQgIWltcG9ydGFudH1bdGV4dC1sZy1sZWZ0XXt0ZXh0LWFsaWduOmxlZnQgIWltcG9ydGFudH1bdGV4dC1sZy1yaWdodF17dGV4dC1hbGlnbjpyaWdodCAhaW1wb3J0YW50fVt0ZXh0LWxnLW5vd3JhcF17d2hpdGUtc3BhY2U6bm93cmFwICFpbXBvcnRhbnR9W3RleHQtbGctd3JhcF17d2hpdGUtc3BhY2U6bm9ybWFsICFpbXBvcnRhbnR9fUBtZWRpYSAobWluLXdpZHRoOiAxMjAwcHgpe1t0ZXh0LXhsLWNlbnRlcl17dGV4dC1hbGlnbjpjZW50ZXIgIWltcG9ydGFudH1bdGV4dC14bC1qdXN0aWZ5XXt0ZXh0LWFsaWduOmp1c3RpZnkgIWltcG9ydGFudH1bdGV4dC14bC1zdGFydF17dGV4dC1hbGlnbjpzdGFydCAhaW1wb3J0YW50fVt0ZXh0LXhsLWVuZF17dGV4dC1hbGlnbjplbmQgIWltcG9ydGFudH1bdGV4dC14bC1sZWZ0XXt0ZXh0LWFsaWduOmxlZnQgIWltcG9ydGFudH1bdGV4dC14bC1yaWdodF17dGV4dC1hbGlnbjpyaWdodCAhaW1wb3J0YW50fVt0ZXh0LXhsLW5vd3JhcF17d2hpdGUtc3BhY2U6bm93cmFwICFpbXBvcnRhbnR9W3RleHQteGwtd3JhcF17d2hpdGUtc3BhY2U6bm9ybWFsICFpbXBvcnRhbnR9fVxuIiwiW3RleHQtdXBwZXJjYXNlXXt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2UgIWltcG9ydGFudH1bdGV4dC1sb3dlcmNhc2Vde3RleHQtdHJhbnNmb3JtOmxvd2VyY2FzZSAhaW1wb3J0YW50fVt0ZXh0LWNhcGl0YWxpemVde3RleHQtdHJhbnNmb3JtOmNhcGl0YWxpemUgIWltcG9ydGFudH1AbWVkaWEgKG1pbi13aWR0aDogNTc2cHgpe1t0ZXh0LXNtLXVwcGVyY2FzZV17dGV4dC10cmFuc2Zvcm06dXBwZXJjYXNlICFpbXBvcnRhbnR9W3RleHQtc20tbG93ZXJjYXNlXXt0ZXh0LXRyYW5zZm9ybTpsb3dlcmNhc2UgIWltcG9ydGFudH1bdGV4dC1zbS1jYXBpdGFsaXplXXt0ZXh0LXRyYW5zZm9ybTpjYXBpdGFsaXplICFpbXBvcnRhbnR9fUBtZWRpYSAobWluLXdpZHRoOiA3NjhweCl7W3RleHQtbWQtdXBwZXJjYXNlXXt0ZXh0LXRyYW5zZm9ybTp1cHBlcmNhc2UgIWltcG9ydGFudH1bdGV4dC1tZC1sb3dlcmNhc2Vde3RleHQtdHJhbnNmb3JtOmxvd2VyY2FzZSAhaW1wb3J0YW50fVt0ZXh0LW1kLWNhcGl0YWxpemVde3RleHQtdHJhbnNmb3JtOmNhcGl0YWxpemUgIWltcG9ydGFudH19QG1lZGlhIChtaW4td2lkdGg6IDk5MnB4KXtbdGV4dC1sZy11cHBlcmNhc2Vde3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZSAhaW1wb3J0YW50fVt0ZXh0LWxnLWxvd2VyY2FzZV17dGV4dC10cmFuc2Zvcm06bG93ZXJjYXNlICFpbXBvcnRhbnR9W3RleHQtbGctY2FwaXRhbGl6ZV17dGV4dC10cmFuc2Zvcm06Y2FwaXRhbGl6ZSAhaW1wb3J0YW50fX1AbWVkaWEgKG1pbi13aWR0aDogMTIwMHB4KXtbdGV4dC14bC11cHBlcmNhc2Vde3RleHQtdHJhbnNmb3JtOnVwcGVyY2FzZSAhaW1wb3J0YW50fVt0ZXh0LXhsLWxvd2VyY2FzZV17dGV4dC10cmFuc2Zvcm06bG93ZXJjYXNlICFpbXBvcnRhbnR9W3RleHQteGwtY2FwaXRhbGl6ZV17dGV4dC10cmFuc2Zvcm06Y2FwaXRhbGl6ZSAhaW1wb3J0YW50fX1cbiIsIlthbGlnbi1zZWxmLXN0YXJ0XXthbGlnbi1zZWxmOmZsZXgtc3RhcnQgIWltcG9ydGFudH1bYWxpZ24tc2VsZi1lbmRde2FsaWduLXNlbGY6ZmxleC1lbmQgIWltcG9ydGFudH1bYWxpZ24tc2VsZi1jZW50ZXJde2FsaWduLXNlbGY6Y2VudGVyICFpbXBvcnRhbnR9W2FsaWduLXNlbGYtc3RyZXRjaF17YWxpZ24tc2VsZjpzdHJldGNoICFpbXBvcnRhbnR9W2FsaWduLXNlbGYtYmFzZWxpbmVde2FsaWduLXNlbGY6YmFzZWxpbmUgIWltcG9ydGFudH1bYWxpZ24tc2VsZi1hdXRvXXthbGlnbi1zZWxmOmF1dG8gIWltcG9ydGFudH1bd3JhcF17ZmxleC13cmFwOndyYXAgIWltcG9ydGFudH1bbm93cmFwXXtmbGV4LXdyYXA6bm93cmFwICFpbXBvcnRhbnR9W3dyYXAtcmV2ZXJzZV17ZmxleC13cmFwOndyYXAtcmV2ZXJzZSAhaW1wb3J0YW50fVtqdXN0aWZ5LWNvbnRlbnQtc3RhcnRde2p1c3RpZnktY29udGVudDpmbGV4LXN0YXJ0ICFpbXBvcnRhbnR9W2p1c3RpZnktY29udGVudC1jZW50ZXJde2p1c3RpZnktY29udGVudDpjZW50ZXIgIWltcG9ydGFudH1banVzdGlmeS1jb250ZW50LWVuZF17anVzdGlmeS1jb250ZW50OmZsZXgtZW5kICFpbXBvcnRhbnR9W2p1c3RpZnktY29udGVudC1hcm91bmRde2p1c3RpZnktY29udGVudDpzcGFjZS1hcm91bmQgIWltcG9ydGFudH1banVzdGlmeS1jb250ZW50LWJldHdlZW5de2p1c3RpZnktY29udGVudDpzcGFjZS1iZXR3ZWVuICFpbXBvcnRhbnR9W2p1c3RpZnktY29udGVudC1ldmVubHlde2p1c3RpZnktY29udGVudDpzcGFjZS1ldmVubHkgIWltcG9ydGFudH1bYWxpZ24taXRlbXMtc3RhcnRde2FsaWduLWl0ZW1zOmZsZXgtc3RhcnQgIWltcG9ydGFudH1bYWxpZ24taXRlbXMtY2VudGVyXXthbGlnbi1pdGVtczpjZW50ZXIgIWltcG9ydGFudH1bYWxpZ24taXRlbXMtZW5kXXthbGlnbi1pdGVtczpmbGV4LWVuZCAhaW1wb3J0YW50fVthbGlnbi1pdGVtcy1zdHJldGNoXXthbGlnbi1pdGVtczpzdHJldGNoICFpbXBvcnRhbnR9W2FsaWduLWl0ZW1zLWJhc2VsaW5lXXthbGlnbi1pdGVtczpiYXNlbGluZSAhaW1wb3J0YW50fVxuIiwiKnsgZm9udC1mYW1pbHk6ICdSb2JvdG8nLCAnTGF0bycsICdSYWxld2F5JywgJ09zd2FsZCcsIHNhbnMtc2VyaWY7IH1cclxuXHJcbi5tYWlue1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGdyaWQtdGVtcGxhdGUtcm93czogMWZyIDRmcjtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB6b29tOiB1bnNldDtcclxufVxyXG5cclxuLyogSEVBREVSICovXHJcbi5oZWFkZXJ7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAyZnIgMWZyIDtcclxufVxyXG4ubWVudWJhciA+IGRpdjpudGgtY2hpbGQob2RkKXsgYmFja2dyb3VuZDogIzIyMjsgfVxyXG4ubWVudWJhcntcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxNGZyIDsgICAgXHJcbn1cclxuLnRvcC1tZW51ID4gZGl2Om50aC1jaGlsZChvZGQpeyBiYWNrZ3JvdW5kOiAjMjIyOyB9XHJcbi50b3AtbWVudXtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IHJlcGVhdCgyLCAxZnIpO1xyXG59XHJcblxyXG5cclxuI3Rvb2xiYXIsICNsb3dlcmJhciwgI3VwcGVyYmFyeyBtYXJnaW46IDA7IHBhZGRpbmc6IDA7IH1cclxuXHJcbi8qIFNJREVCQVIgKi9cclxuLndyYXBwZXIgPiAjcmlnaHRfd3MgPiAjd29ya3NwYWNleyBiYWNrZ3JvdW5kOiB3aGl0ZTsgcGFkZGluZzogMWVtOyB9XHJcbi53cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICAvKiBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDEwMHB4IGF1dG87ICovXHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDBmciAxZnI7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgIFxyXG59XHJcbi5zaG93U3ltYm9sUGFuZWwgeyBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDEwMHB4IGF1dG87IH1cclxuI2xlZnRfc3ltYm9scyB7XHJcbiAgICBmbG9hdDogbGVmdDsgXHJcbiAgICAvKiBiYWNrZ3JvdW5kLWNvbG9yOiBhcXVhOyAqL1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuI3JpZ2h0X3dzIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDVmciAxZnI7XHJcbiAgICAvKiBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciA1ZnI7ICovXHJcbiAgICBncmlkLWNvbHVtbi1nYXA6IDAuMjVlbTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcbi5zaWRlYmFyeyBcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlOyBcclxuICAgIG1hcmdpbjogMDsgXHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxLjVmciA0ZnI7XHJcbn1cclxuLnNpZGV2aWV3eyBwYWRkaW5nOiAwOyBoZWlnaHQ6IDEwMCU7IH1cclxuLnRhYnMgYXsgXHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGJhY2tncm91bmQ6ICMzMzMzMzM7IFxyXG4gICAgYm9yZGVyLXdpZHRoOiAwIDAgNXB4O1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1jb2xvcjogcmdiYSgxODcsIDE5NSwgMTk5LCAwLjkwNCk7XHJcbiAgICBjb2xvcjogIzAzOWJlNTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7IFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi50YWJzeyBkaXNwbGF5OiBncmlkOyBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgzLCAxZnIpOyB9XHJcbi50YWJzIGE6aG92ZXJ7XHJcbiAgICBjb2xvcjogI2RkZDtcclxuICAgIGJhY2tncm91bmQ6ICMwMzliZTU7XHJcbiAgICBib3JkZXItd2lkdGg6IDAgMCA1cHg7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjMzMzO1xyXG59XHJcbi50YWJzIGEuYWN0aXZlLWxpbmsge1xyXG4gICAgY29sb3I6ICMwMzliZTU7XHJcbiAgICBib3JkZXItd2lkdGg6IDAgMCA1cHg7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjMDM5YmU1O1xyXG4gICAgYmFja2dyb3VuZDogI2RkZDtcclxufVxyXG5saSBheyBcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgYmFja2dyb3VuZDogI0E5QjFCNDsgXHJcbiAgICBjb2xvcjogIzMzMztcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDAgMTBweDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjsgXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxubGkgYTpob3ZlcnsgY29sb3I6ICMwMzliZTU7IH0gXHJcbiN3b3Jrc3BhY2UgPiBkaXZ7IG1hcmdpbjogYXV0bzsgfVxyXG4vKiAjd29ya3NwYWNleyBvdmVyZmxvdzogYXV0bzsgfSAqL1xyXG5cclxuLyoqKiBEUk9QLURPV04gTUVOVSBbcGxhY2Vob2xkZXIgc3R5bGVzXSAqKiovXHJcbiNsb3dlcmJhciB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzMzMztcclxuICAgIGZvbnQtZmFtaWx5OiBBcmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmO1xyXG59XHJcbi5kcm9wZG93biB7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbn1cclxuLmRyb3Bkb3duIC5kcm9wYnRuIHtcclxuICAgIGZvbnQtc2l6ZTogMTJwdDsgICAgXHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgY29sb3I6ICNGOEY4Rjg7XHJcbiAgICBwYWRkaW5nOiAxNHB4IDE2cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBpbmhlcml0O1xyXG4gICAgZm9udC1mYW1pbHk6IGluaGVyaXQ7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG4jbG93ZXJiYXIgYTpob3ZlciwgLmRyb3Bkb3duOmhvdmVyIC5kcm9wYnRuIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZGQ7XHJcbiAgICBjb2xvcjogIzAzOWJlNTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4uZHJvcGRvd24tY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2RkZDtcclxuICAgIG1pbi13aWR0aDogMTYwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggOHB4IDE2cHggMHB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgIHotaW5kZXg6IDE7XHJcbn1cclxuLmRyb3Bkb3duLWNvbnRlbnQgYSB7XHJcbiAgICBmbG9hdDogbm9uZTtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIHBhZGRpbmc6IDEycHggMTZweDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4uZHJvcGRvd24tY29udGVudCBhOmhvdmVyIHsgYmFja2dyb3VuZC1jb2xvcjogI2RkZDsgfVxyXG4uZHJvcGRvd246aG92ZXIgLmRyb3Bkb3duLWNvbnRlbnQgeyBkaXNwbGF5OiBibG9jazsgfVxyXG5cclxuLyogIFNJREUgTUVOVSAgKi9cclxuI3NpZGVtZW51X2xpc3R7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzMzMzO1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbn1cclxuI3NpZGVtZW51X2xpc3QgaW9uLWl0ZW06aG92ZXJ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gICAgLyogY29sb3I6ICNkZGQ7ICovXHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuI2J0bl9uZXdQcm9qZWN0OmhvdmVyIHsgY29sb3I6ICM1NENCQzk7IH1cclxuI2J0bl9vcGVuUHJvamVjdDpob3ZlciB7IGNvbG9yOiAjZmZjZTAwOyB9XHJcbiNidG5fc2F2ZVByb2plY3Q6aG92ZXIgeyBjb2xvcjogIzRjOGRmZjsgfVxyXG4jYnRuX2RlYnVnUHJvZ3JhbTpob3ZlciB7IGNvbG9yOiAjMTBkYzYwOyB9XHJcbiNidG5fZ2VuZXJhdGVDb2RlOmhvdmVyIHsgY29sb3I6ICNBRkYzQ0E7IH1cclxuI2J0bl9jbGVhcldvcmtzcGFjZTpob3ZlciB7IGNvbG9yOiAjZjA0MTQxOyB9XHJcbiNidG5fZ2V0dGluZ1N0YXJ0ZWRQYWdlOmhvdmVyLCAjYnRuX3R1dG9yaWFsUGFnZTpob3ZlcixcclxuI2J0bl90aGVtZVBhZ2U6aG92ZXIsICNidG5fYWJvdXRQYWdlOmhvdmVyLFxyXG4jYnRuX2ZlZWRiYWNrUGFnZTpob3ZlciwgI2J0bl9sb2dPdXQ6aG92ZXIsXHJcbiNidG5fZ29PbmxpbmU6aG92ZXIsICNidG5fYmFja1RvV2VsY29tZTpob3ZlciB7IGNvbG9yOiAjZGRkOyB9XHJcblxyXG50ZXh0YXJlYXsgXHJcbiAvKiBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAganVzdGlmeS1jb250ZW50OiBiYXNlbGluZTtcclxuICAgIHdpZHRoOiAxMDAlOyBwYWRkaW5nOiA1cHg7IGZsb2F0OiByaWdodDsgXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzO1xyXG4gICAgIFxyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7IFxyXG4gICAgcmVzaXplOiBub25lOyB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7UmVzaXplIEVkaWxtZSBBw6fEsWxhIEJpbGlyKi9cclxuICB9XHJcblxyXG4vKiBTeW1ib2wgUG9wIFVwICgucG9wb3Zlci1jb250ZW50KSAgRGXEn2nFn3RpIDIwMCBkw7wqL1xyXG4uc3ltUG9wVXAge1xyXG4gIC0td2lkdGg6IDMwcHg7XHJcbiAvKiAtLWhlaWdodDogNTAwcHg7ICovXHJcbn1cclxuXHJcbi5zeW1Qb3BVcCAucG9wb3Zlci13cmFwcGVyIC5wb3BvdmVyLWNvbnRlbnQge1xyXG4gIC8qIHRvcDogMTIwcHg7XHJcbiAgbGVmdDogNjAwcHg7ICovXHJcbiBtYXJnaW46IGF1dG87XHJcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG5cclxuICAvKiBoZWlnaHQ6IDQ1MHB4OyAqL1xyXG59XHJcblxyXG4vKiBTeW1ib2wgUG9wIFVwICgucG9wb3Zlci1jb250ZW50KSAqL1xyXG4uc3ltYm9sUHJvbXB0QVMge1xyXG4gICAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gIC8qIGhlaWdodDogNDUwcHg7ICovXHJcbiAgXHJcbn1cclxuICBcclxuLnN5bWJvbFByb21wdEFTIC5wb3BvdmVyLXdyYXBwZXIgLnBvcG92ZXItY29udGVudCB7XHJcbiAgLyogdG9wOiAxMjBweDtcclxuICBsZWZ0OiA2MDBweDsgKi9cclxuICBtYXJnaW4tbGVmdDogODVweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gIFxyXG4gLyogb3ZlcmZsb3cteDogc2Nyb2xsOyAqL1xyXG4gIC8qIGhlaWdodDogNDUwcHg7ICovXHJcbn1cclxuXHJcbi8qIFN5bWJvbCBNb2RhbCBUZXh0Ym94IEZvY3VzICovXHJcbi5kaWFsb2dUZXh0Ym94IHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHJnYigyNDgsIDI0NiwgMjQ2KTtcclxuICAgIFxyXG4gIH1cclxuXHJcbi8qIENsZWFyIFdvcmtzcGFjZSBBbGVydCAqL1xyXG4uY2xlYXJXUy15ZXMgeyAtLWJhY2tncm91bmQ6ICNmMDQxNDE7IH1cclxuXHJcbi5hYWxlcnRfaW5wdXR7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgYm9yZGVyLXdpZHRoOiA0NXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiBibGFjaztcclxuICAgIGJvcmRlci1pbmxpbmUtc3RhcnQtY29sb3I6IGJsYWNrO1xyXG59XHJcbi5hbGVydFRpdGxle1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOmNyaW1zb247XHJcbiAgICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuLmVycm9yQWxlcnR7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICBjb2xvcjpjcmltc29uO1xyXG4gICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuLm5vZXJyb3JBbGVydHtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgXHJcbiAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uZXJyb3JXQWxlcnR7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICBjb2xvcjpnb2xkO1xyXG4gICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIC5hYWxlcnRfaW5wdXR7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgYm9yZGVyLXdpZHRoOiA0NXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiBibGFjaztcclxuICAgIGJvcmRlci1pbmxpbmUtc3RhcnQtY29sb3I6IGJsYWNrO1xyXG59XHJcbi5hbGVydFRpdGxle1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOmNyaW1zb247XHJcbn1cclxuLmVycm9yQWxlcnR7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICBjb2xvcjpjcmltc29uO1xyXG4gICBmb250LXNpemU6IDEycHg7XHJcbiAgIHdvcmQtd3JhcDogbm9ybWFsO1xyXG4gICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbn1cclxuLm5vZXJyb3JBbGVydHtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICBjb2xvcjogd2hpdGU7XHJcbiAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbi5lcnJvcldBbGVydHtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgIGNvbG9yOmdvbGQ7XHJcbiAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgd29yZC13cmFwOiBub3JtYWw7XHJcbiAgIHdpZHRoOiBmaXQtY29udGVudDtcclxufVxyXG59XHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjAwcHgpIHtcclxuICAgIC5hYWxlcnRfaW5wdXR7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGJvcmRlci13aWR0aDogNDVweDtcclxuICAgICAgICBib3JkZXItY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIGJvcmRlci1pbmxpbmUtc3RhcnQtY29sb3I6IGJsYWNrO1xyXG4gICAgfVxyXG4gICAgLmFsZXJ0VGl0bGV7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGNvbG9yOmNyaW1zb247XHJcbiAgICB9XHJcbiAgICAuZXJyb3JBbGVydHtcclxuICAgICAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgIGNvbG9yOmNyaW1zb247XHJcbiAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICB3b3JkLXdyYXA6IG5vcm1hbDtcclxuICAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcclxuICAgIH1cclxuICAgIC5ub2Vycm9yQWxlcnR7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbiAgICAgICBvdmVyZmxvdy14OiBzY3JvbGw7XHJcbiAgICB9XHJcbiAgICAuZXJyb3JXQWxlcnR7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICBjb2xvcjpnb2xkO1xyXG4gICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgd29yZC13cmFwOiBub3JtYWw7XHJcbiAgICAgICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbiAgICAgICBvdmVyZmxvdy14OiBzY3JvbGw7XHJcbiAgICB9XHJcbn0iLCIvKiAtLS0tRHJhZ3VsYSBDU1MtLS0tICovXHJcblxyXG4vKiBpbi1mbGlnaHQgY2xvbmUgKi9cclxuLmd1LW1pcnJvciB7XHJcbiAgcG9zaXRpb246IGZpeGVkICFpbXBvcnRhbnQ7XHJcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbiAgei1pbmRleDogOTk5OSAhaW1wb3J0YW50O1xyXG4gIG9wYWNpdHk6IDAuODtcclxuICAtbXMtZmlsdGVyOiBcInByb2dpZDpEWEltYWdlVHJhbnNmb3JtLk1pY3Jvc29mdC5BbHBoYShPcGFjaXR5PTgwKVwiO1xyXG4gIGZpbHRlcjogYWxwaGEob3BhY2l0eT04MCk7XHJcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuIFxyXG4vKiBoaWdoLXBlcmZvcm1hbmNlIGRpc3BsYXk6bm9uZTsgaGVscGVyICovXHJcbi5ndS1oaWRlIHtcclxuICBsZWZ0OiAtOTk5OXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuIFxyXG4vKiBhZGRlZCB0byBtaXJyb3JDb250YWluZXIgKGRlZmF1bHQgPSBib2R5KSB3aGlsZSBkcmFnZ2luZyAqL1xyXG4uZ3UtdW5zZWxlY3RhYmxlIHtcclxuICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgLW1vei11c2VyLXNlbGVjdDogbm9uZSAhaW1wb3J0YW50O1xyXG4gIC1tcy11c2VyLXNlbGVjdDogbm9uZSAhaW1wb3J0YW50O1xyXG4gIHVzZXItc2VsZWN0OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgY3Vyc29yOiAtd2Via2l0LWdyYWJiaW5nOyBcclxuICBjdXJzb3I6IGdyYWJiaW5nO1xyXG59XHJcbiBcclxuLyogYWRkZWQgdG8gdGhlIHNvdXJjZSBlbGVtZW50IHdoaWxlIGl0cyBtaXJyb3IgaXMgZHJhZ2dlZCAqL1xyXG4uZ3UtdHJhbnNpdCB7XHJcbiAgb3BhY2l0eTogMC4yO1xyXG4gIC1tcy1maWx0ZXI6IFwicHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LkFscGhhKE9wYWNpdHk9MjApXCI7XHJcbiAgZmlsdGVyOiBhbHBoYShvcGFjaXR5PTIwKTtcclxuICBcclxufSJdfQ== */", '', '']]

/***/ }),

/***/ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/theme/variables.scss":
/*!*******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src??embedded!./node_modules/sass-loader/lib/loader.js??ref--14-3!./src/theme/variables.scss ***!
  \*******************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = [[module.i, "/** Ionic CSS Variables **/\n:root {\n  /** primary **/\n  --ion-color-primary: #333333;\n  --ion-color-primary-rgb: 56,128,255;\n  --ion-color-primary-contrast: #ffffff;\n  --ion-color-primary-contrast-rgb: 255,255,255;\n  --ion-color-primary-shade: #3171e0;\n  --ion-color-primary-tint: #4c8dff;\n  /** secondary **/\n  --ion-color-secondary: #DDDDDD;\n  --ion-color-secondary-rgb: 12,209,232;\n  --ion-color-secondary-contrast: #ffffff;\n  --ion-color-secondary-contrast-rgb: 255,255,255;\n  --ion-color-secondary-shade: #0bb8cc;\n  --ion-color-secondary-tint: #24d6ea;\n  /** tertiary **/\n  --ion-color-tertiary: #A9B1B4;\n  --ion-color-tertiary-rgb: 112,68,255;\n  --ion-color-tertiary-contrast: #ffffff;\n  --ion-color-tertiary-contrast-rgb: 255,255,255;\n  --ion-color-tertiary-shade: #633ce0;\n  --ion-color-tertiary-tint: #7e57ff;\n  /** success **/\n  --ion-color-success: #10dc60;\n  --ion-color-success-rgb: 16,220,96;\n  --ion-color-success-contrast: #ffffff;\n  --ion-color-success-contrast-rgb: 255,255,255;\n  --ion-color-success-shade: #0ec254;\n  --ion-color-success-tint: #28e070;\n  /** warning **/\n  --ion-color-warning: #ffce00;\n  --ion-color-warning-rgb: 255,206,0;\n  --ion-color-warning-contrast: #ffffff;\n  --ion-color-warning-contrast-rgb: 255,255,255;\n  --ion-color-warning-shade: #e0b500;\n  --ion-color-warning-tint: #ffd31a;\n  /** danger **/\n  --ion-color-danger: #f04141;\n  --ion-color-danger-rgb: 245,61,61;\n  --ion-color-danger-contrast: #ffffff;\n  --ion-color-danger-contrast-rgb: 255,255,255;\n  --ion-color-danger-shade: #d33939;\n  --ion-color-danger-tint: #f25454;\n  /** dark **/\n  --ion-color-dark: #222428;\n  --ion-color-dark-rgb: 34,34,34;\n  --ion-color-dark-contrast: #ffffff;\n  --ion-color-dark-contrast-rgb: 255,255,255;\n  --ion-color-dark-shade: #1e2023;\n  --ion-color-dark-tint: #383a3e;\n  /** medium **/\n  --ion-color-medium: #989aa2;\n  --ion-color-medium-rgb: 152,154,162;\n  --ion-color-medium-contrast: #ffffff;\n  --ion-color-medium-contrast-rgb: 255,255,255;\n  --ion-color-medium-shade: #86888f;\n  --ion-color-medium-tint: #a2a4ab;\n  /** light **/\n  --ion-color-light: #f4f5f8;\n  --ion-color-light-rgb: 244,244,244;\n  --ion-color-light-contrast: #000000;\n  --ion-color-light-contrast-rgb: 0,0,0;\n  --ion-color-light-shade: #d7d8da;\n  --ion-color-light-tint: #f5f6f9;\n  /** cover **/\n  --ion-color-cover: #343A40;\n  --ion-color-cover-rgb: 52, 58, 64;\n  --ion-color-cover-contrast: #CBC5BF;\n  --ion-color-cover-contrast-rgb: 203, 197, 191;\n  --ion-color-cover-shade: #22262A;\n  --ion-color-cover-tint: #343A40; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy90aGVtZS9DOlxcVXNlcnNcXEhhc2FuX01vbnN0ZXJcXENIQVAvc3JjXFx0aGVtZVxcdmFyaWFibGVzLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0EsMkJBQTJCO0FBQzNCO0VBRUUsZUFBZTtFQUNmLDZCQUFvQjtFQUNwQixvQ0FBd0I7RUFDeEIsc0NBQTZCO0VBQzdCLDhDQUFpQztFQUNqQyxtQ0FBMEI7RUFDMUIsa0NBQXlCO0VBRXpCLGlCQUFpQjtFQUNqQiwrQkFBc0I7RUFDdEIsc0NBQTBCO0VBQzFCLHdDQUErQjtFQUMvQixnREFBbUM7RUFDbkMscUNBQTRCO0VBQzVCLG9DQUEyQjtFQUUzQixnQkFBZ0I7RUFDaEIsOEJBQXFCO0VBQ3JCLHFDQUF5QjtFQUN6Qix1Q0FBOEI7RUFDOUIsK0NBQWtDO0VBQ2xDLG9DQUEyQjtFQUMzQixtQ0FBMEI7RUFFMUIsZUFBZTtFQUNmLDZCQUFvQjtFQUNwQixtQ0FBd0I7RUFDeEIsc0NBQTZCO0VBQzdCLDhDQUFpQztFQUNqQyxtQ0FBMEI7RUFDMUIsa0NBQXlCO0VBRXpCLGVBQWU7RUFDZiw2QkFBb0I7RUFDcEIsbUNBQXdCO0VBQ3hCLHNDQUE2QjtFQUM3Qiw4Q0FBaUM7RUFDakMsbUNBQTBCO0VBQzFCLGtDQUF5QjtFQUV6QixjQUFjO0VBQ2QsNEJBQW1CO0VBQ25CLGtDQUF1QjtFQUN2QixxQ0FBNEI7RUFDNUIsNkNBQWdDO0VBQ2hDLGtDQUF5QjtFQUN6QixpQ0FBd0I7RUFFeEIsWUFBWTtFQUNaLDBCQUFpQjtFQUNqQiwrQkFBcUI7RUFDckIsbUNBQTBCO0VBQzFCLDJDQUE4QjtFQUM5QixnQ0FBdUI7RUFDdkIsK0JBQXNCO0VBRXRCLGNBQWM7RUFDZCw0QkFBbUI7RUFDbkIsb0NBQXVCO0VBQ3ZCLHFDQUE0QjtFQUM1Qiw2Q0FBZ0M7RUFDaEMsa0NBQXlCO0VBQ3pCLGlDQUF3QjtFQUV4QixhQUFhO0VBQ2IsMkJBQWtCO0VBQ2xCLG1DQUFzQjtFQUN0QixvQ0FBMkI7RUFDM0Isc0NBQStCO0VBQy9CLGlDQUF3QjtFQUN4QixnQ0FBdUI7RUFFdkIsYUFBYTtFQUNiLDJCQUFrQjtFQUNsQixrQ0FBc0I7RUFDdEIsb0NBQTJCO0VBQzNCLDhDQUErQjtFQUMvQixpQ0FBd0I7RUFDeEIsZ0NBQXVCLEVBQ3hCIiwiZmlsZSI6InNyYy90aGVtZS92YXJpYWJsZXMuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIElvbmljIFZhcmlhYmxlcyBhbmQgVGhlbWluZy4gRm9yIG1vcmUgaW5mbywgcGxlYXNlIHNlZTpcclxuLy8gaHR0cDovL2lvbmljZnJhbWV3b3JrLmNvbS9kb2NzL3RoZW1pbmcvXHJcblxyXG4vKiogSW9uaWMgQ1NTIFZhcmlhYmxlcyAqKi9cclxuOnJvb3Qge1xyXG5cclxuICAvKiogcHJpbWFyeSAqKi9cclxuICAtLWlvbi1jb2xvci1wcmltYXJ5OiAjMzMzMzMzO1xyXG4gIC0taW9uLWNvbG9yLXByaW1hcnktcmdiOiA1NiwxMjgsMjU1O1xyXG4gIC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3Q6ICNmZmZmZmY7XHJcbiAgLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdC1yZ2I6IDI1NSwyNTUsMjU1O1xyXG4gIC0taW9uLWNvbG9yLXByaW1hcnktc2hhZGU6ICMzMTcxZTA7XHJcbiAgLS1pb24tY29sb3ItcHJpbWFyeS10aW50OiAjNGM4ZGZmO1xyXG5cclxuICAvKiogc2Vjb25kYXJ5ICoqL1xyXG4gIC0taW9uLWNvbG9yLXNlY29uZGFyeTogI0RERERERDtcclxuICAtLWlvbi1jb2xvci1zZWNvbmRhcnktcmdiOiAxMiwyMDksMjMyO1xyXG4gIC0taW9uLWNvbG9yLXNlY29uZGFyeS1jb250cmFzdDogI2ZmZmZmZjtcclxuICAtLWlvbi1jb2xvci1zZWNvbmRhcnktY29udHJhc3QtcmdiOiAyNTUsMjU1LDI1NTtcclxuICAtLWlvbi1jb2xvci1zZWNvbmRhcnktc2hhZGU6ICMwYmI4Y2M7XHJcbiAgLS1pb24tY29sb3Itc2Vjb25kYXJ5LXRpbnQ6ICMyNGQ2ZWE7XHJcblxyXG4gIC8qKiB0ZXJ0aWFyeSAqKi9cclxuICAtLWlvbi1jb2xvci10ZXJ0aWFyeTogI0E5QjFCNDtcclxuICAtLWlvbi1jb2xvci10ZXJ0aWFyeS1yZ2I6IDExMiw2OCwyNTU7XHJcbiAgLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3Q6ICNmZmZmZmY7XHJcbiAgLS1pb24tY29sb3ItdGVydGlhcnktY29udHJhc3QtcmdiOiAyNTUsMjU1LDI1NTtcclxuICAtLWlvbi1jb2xvci10ZXJ0aWFyeS1zaGFkZTogIzYzM2NlMDtcclxuICAtLWlvbi1jb2xvci10ZXJ0aWFyeS10aW50OiAjN2U1N2ZmO1xyXG5cclxuICAvKiogc3VjY2VzcyAqKi9cclxuICAtLWlvbi1jb2xvci1zdWNjZXNzOiAjMTBkYzYwO1xyXG4gIC0taW9uLWNvbG9yLXN1Y2Nlc3MtcmdiOiAxNiwyMjAsOTY7XHJcbiAgLS1pb24tY29sb3Itc3VjY2Vzcy1jb250cmFzdDogI2ZmZmZmZjtcclxuICAtLWlvbi1jb2xvci1zdWNjZXNzLWNvbnRyYXN0LXJnYjogMjU1LDI1NSwyNTU7XHJcbiAgLS1pb24tY29sb3Itc3VjY2Vzcy1zaGFkZTogIzBlYzI1NDtcclxuICAtLWlvbi1jb2xvci1zdWNjZXNzLXRpbnQ6ICMyOGUwNzA7XHJcblxyXG4gIC8qKiB3YXJuaW5nICoqL1xyXG4gIC0taW9uLWNvbG9yLXdhcm5pbmc6ICNmZmNlMDA7XHJcbiAgLS1pb24tY29sb3Itd2FybmluZy1yZ2I6IDI1NSwyMDYsMDtcclxuICAtLWlvbi1jb2xvci13YXJuaW5nLWNvbnRyYXN0OiAjZmZmZmZmO1xyXG4gIC0taW9uLWNvbG9yLXdhcm5pbmctY29udHJhc3QtcmdiOiAyNTUsMjU1LDI1NTtcclxuICAtLWlvbi1jb2xvci13YXJuaW5nLXNoYWRlOiAjZTBiNTAwO1xyXG4gIC0taW9uLWNvbG9yLXdhcm5pbmctdGludDogI2ZmZDMxYTtcclxuXHJcbiAgLyoqIGRhbmdlciAqKi9cclxuICAtLWlvbi1jb2xvci1kYW5nZXI6ICNmMDQxNDE7XHJcbiAgLS1pb24tY29sb3ItZGFuZ2VyLXJnYjogMjQ1LDYxLDYxO1xyXG4gIC0taW9uLWNvbG9yLWRhbmdlci1jb250cmFzdDogI2ZmZmZmZjtcclxuICAtLWlvbi1jb2xvci1kYW5nZXItY29udHJhc3QtcmdiOiAyNTUsMjU1LDI1NTtcclxuICAtLWlvbi1jb2xvci1kYW5nZXItc2hhZGU6ICNkMzM5Mzk7XHJcbiAgLS1pb24tY29sb3ItZGFuZ2VyLXRpbnQ6ICNmMjU0NTQ7XHJcblxyXG4gIC8qKiBkYXJrICoqL1xyXG4gIC0taW9uLWNvbG9yLWRhcms6ICMyMjI0Mjg7XHJcbiAgLS1pb24tY29sb3ItZGFyay1yZ2I6IDM0LDM0LDM0O1xyXG4gIC0taW9uLWNvbG9yLWRhcmstY29udHJhc3Q6ICNmZmZmZmY7XHJcbiAgLS1pb24tY29sb3ItZGFyay1jb250cmFzdC1yZ2I6IDI1NSwyNTUsMjU1O1xyXG4gIC0taW9uLWNvbG9yLWRhcmstc2hhZGU6ICMxZTIwMjM7XHJcbiAgLS1pb24tY29sb3ItZGFyay10aW50OiAjMzgzYTNlO1xyXG5cclxuICAvKiogbWVkaXVtICoqL1xyXG4gIC0taW9uLWNvbG9yLW1lZGl1bTogIzk4OWFhMjtcclxuICAtLWlvbi1jb2xvci1tZWRpdW0tcmdiOiAxNTIsMTU0LDE2MjtcclxuICAtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3Q6ICNmZmZmZmY7XHJcbiAgLS1pb24tY29sb3ItbWVkaXVtLWNvbnRyYXN0LXJnYjogMjU1LDI1NSwyNTU7XHJcbiAgLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlOiAjODY4ODhmO1xyXG4gIC0taW9uLWNvbG9yLW1lZGl1bS10aW50OiAjYTJhNGFiO1xyXG5cclxuICAvKiogbGlnaHQgKiovXHJcbiAgLS1pb24tY29sb3ItbGlnaHQ6ICNmNGY1Zjg7XHJcbiAgLS1pb24tY29sb3ItbGlnaHQtcmdiOiAyNDQsMjQ0LDI0NDtcclxuICAtLWlvbi1jb2xvci1saWdodC1jb250cmFzdDogIzAwMDAwMDtcclxuICAtLWlvbi1jb2xvci1saWdodC1jb250cmFzdC1yZ2I6IDAsMCwwO1xyXG4gIC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlOiAjZDdkOGRhO1xyXG4gIC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQ6ICNmNWY2Zjk7XHJcblxyXG4gIC8qKiBjb3ZlciAqKi9cclxuICAtLWlvbi1jb2xvci1jb3ZlcjogIzM0M0E0MDtcclxuICAtLWlvbi1jb2xvci1jb3Zlci1yZ2I6IDUyLCA1OCwgNjQ7XHJcbiAgLS1pb24tY29sb3ItY292ZXItY29udHJhc3Q6ICNDQkM1QkY7XHJcbiAgLS1pb24tY29sb3ItY292ZXItY29udHJhc3QtcmdiOiAyMDMsIDE5NywgMTkxO1xyXG4gIC0taW9uLWNvbG9yLWNvdmVyLXNoYWRlOiAjMjIyNjJBO1xyXG4gIC0taW9uLWNvbG9yLWNvdmVyLXRpbnQ6ICMzNDNBNDA7XHJcbn1cclxuXHJcbiRjb2xvcnM6IChcclxuICBwcmltYXJ5OiAgICAjMzMzMzMzLFxyXG4gIHNlY29uZGFyeTogICNEREREREQsXHJcbiAgZGFuZ2VyOiAgICAgI2Y1M2QzZCxcclxuICBsaWdodDogICAgICByZ2JhKDE4NywgMTk1LCAxOTksIDAuOTA0KSxcclxuICBkYXJrOiAgICAgICAjMTExLFxyXG4gIGNvdmVyOiAjMzQzQTQwXHJcbik7XHJcblxyXG4iXX0= */", '', '']]

/***/ }),

/***/ "./node_modules/style-loader/lib/addStyles.js":
/*!****************************************************!*\
  !*** ./node_modules/style-loader/lib/addStyles.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/

var stylesInDom = {};

var	memoize = function (fn) {
	var memo;

	return function () {
		if (typeof memo === "undefined") memo = fn.apply(this, arguments);
		return memo;
	};
};

var isOldIE = memoize(function () {
	// Test for IE <= 9 as proposed by Browserhacks
	// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
	// Tests for existence of standard globals is to allow style-loader
	// to operate correctly into non-standard environments
	// @see https://github.com/webpack-contrib/style-loader/issues/177
	return window && document && document.all && !window.atob;
});

var getTarget = function (target, parent) {
  if (parent){
    return parent.querySelector(target);
  }
  return document.querySelector(target);
};

var getElement = (function (fn) {
	var memo = {};

	return function(target, parent) {
                // If passing function in options, then use it for resolve "head" element.
                // Useful for Shadow Root style i.e
                // {
                //   insertInto: function () { return document.querySelector("#foo").shadowRoot }
                // }
                if (typeof target === 'function') {
                        return target();
                }
                if (typeof memo[target] === "undefined") {
			var styleTarget = getTarget.call(this, target, parent);
			// Special case to return head of iframe instead of iframe itself
			if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
				try {
					// This will throw an exception if access to iframe is blocked
					// due to cross-origin restrictions
					styleTarget = styleTarget.contentDocument.head;
				} catch(e) {
					styleTarget = null;
				}
			}
			memo[target] = styleTarget;
		}
		return memo[target]
	};
})();

var singleton = null;
var	singletonCounter = 0;
var	stylesInsertedAtTop = [];

var	fixUrls = __webpack_require__(/*! ./urls */ "./node_modules/style-loader/lib/urls.js");

module.exports = function(list, options) {
	if (typeof DEBUG !== "undefined" && DEBUG) {
		if (typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};

	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (!options.singleton && typeof options.singleton !== "boolean") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
        if (!options.insertInto) options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (!options.insertAt) options.insertAt = "bottom";

	var styles = listToStyles(list, options);

	addStylesToDom(styles, options);

	return function update (newList) {
		var mayRemove = [];

		for (var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];

			domStyle.refs--;
			mayRemove.push(domStyle);
		}

		if(newList) {
			var newStyles = listToStyles(newList, options);
			addStylesToDom(newStyles, options);
		}

		for (var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];

			if(domStyle.refs === 0) {
				for (var j = 0; j < domStyle.parts.length; j++) domStyle.parts[j]();

				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom (styles, options) {
	for (var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];

		if(domStyle) {
			domStyle.refs++;

			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}

			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];

			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}

			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles (list, options) {
	var styles = [];
	var newStyles = {};

	for (var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = options.base ? item[0] + options.base : item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};

		if(!newStyles[id]) styles.push(newStyles[id] = {id: id, parts: [part]});
		else newStyles[id].parts.push(part);
	}

	return styles;
}

function insertStyleElement (options, style) {
	var target = getElement(options.insertInto)

	if (!target) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}

	var lastStyleElementInsertedAtTop = stylesInsertedAtTop[stylesInsertedAtTop.length - 1];

	if (options.insertAt === "top") {
		if (!lastStyleElementInsertedAtTop) {
			target.insertBefore(style, target.firstChild);
		} else if (lastStyleElementInsertedAtTop.nextSibling) {
			target.insertBefore(style, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			target.appendChild(style);
		}
		stylesInsertedAtTop.push(style);
	} else if (options.insertAt === "bottom") {
		target.appendChild(style);
	} else if (typeof options.insertAt === "object" && options.insertAt.before) {
		var nextSibling = getElement(options.insertAt.before, target);
		target.insertBefore(style, nextSibling);
	} else {
		throw new Error("[Style Loader]\n\n Invalid value for parameter 'insertAt' ('options.insertAt') found.\n Must be 'top', 'bottom', or Object.\n (https://github.com/webpack-contrib/style-loader#insertat)\n");
	}
}

function removeStyleElement (style) {
	if (style.parentNode === null) return false;
	style.parentNode.removeChild(style);

	var idx = stylesInsertedAtTop.indexOf(style);
	if(idx >= 0) {
		stylesInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement (options) {
	var style = document.createElement("style");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}

	if(options.attrs.nonce === undefined) {
		var nonce = getNonce();
		if (nonce) {
			options.attrs.nonce = nonce;
		}
	}

	addAttrs(style, options.attrs);
	insertStyleElement(options, style);

	return style;
}

function createLinkElement (options) {
	var link = document.createElement("link");

	if(options.attrs.type === undefined) {
		options.attrs.type = "text/css";
	}
	options.attrs.rel = "stylesheet";

	addAttrs(link, options.attrs);
	insertStyleElement(options, link);

	return link;
}

function addAttrs (el, attrs) {
	Object.keys(attrs).forEach(function (key) {
		el.setAttribute(key, attrs[key]);
	});
}

function getNonce() {
	if (false) {}

	return __webpack_require__.nc;
}

function addStyle (obj, options) {
	var style, update, remove, result;

	// If a transform function was defined, run it on the css
	if (options.transform && obj.css) {
	    result = options.transform(obj.css);

	    if (result) {
	    	// If transform returns a value, use that instead of the original css.
	    	// This allows running runtime transformations on the css.
	    	obj.css = result;
	    } else {
	    	// If the transform function returns a falsy value, don't add this css.
	    	// This allows conditional loading of css
	    	return function() {
	    		// noop
	    	};
	    }
	}

	if (options.singleton) {
		var styleIndex = singletonCounter++;

		style = singleton || (singleton = createStyleElement(options));

		update = applyToSingletonTag.bind(null, style, styleIndex, false);
		remove = applyToSingletonTag.bind(null, style, styleIndex, true);

	} else if (
		obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function"
	) {
		style = createLinkElement(options);
		update = updateLink.bind(null, style, options);
		remove = function () {
			removeStyleElement(style);

			if(style.href) URL.revokeObjectURL(style.href);
		};
	} else {
		style = createStyleElement(options);
		update = applyToTag.bind(null, style);
		remove = function () {
			removeStyleElement(style);
		};
	}

	update(obj);

	return function updateStyle (newObj) {
		if (newObj) {
			if (
				newObj.css === obj.css &&
				newObj.media === obj.media &&
				newObj.sourceMap === obj.sourceMap
			) {
				return;
			}

			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;

		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag (style, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (style.styleSheet) {
		style.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = style.childNodes;

		if (childNodes[index]) style.removeChild(childNodes[index]);

		if (childNodes.length) {
			style.insertBefore(cssNode, childNodes[index]);
		} else {
			style.appendChild(cssNode);
		}
	}
}

function applyToTag (style, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		style.setAttribute("media", media)
	}

	if(style.styleSheet) {
		style.styleSheet.cssText = css;
	} else {
		while(style.firstChild) {
			style.removeChild(style.firstChild);
		}

		style.appendChild(document.createTextNode(css));
	}
}

function updateLink (link, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/*
		If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
		and there is no publicPath defined then lets turn convertToAbsoluteUrls
		on by default.  Otherwise default to the convertToAbsoluteUrls option
		directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls) {
		css = fixUrls(css);
	}

	if (sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = link.href;

	link.href = URL.createObjectURL(blob);

	if(oldSrc) URL.revokeObjectURL(oldSrc);
}


/***/ }),

/***/ "./node_modules/style-loader/lib/urls.js":
/*!***********************************************!*\
  !*** ./node_modules/style-loader/lib/urls.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/|\s*$)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),

/***/ "./src/global.scss":
/*!*************************!*\
  !*** ./src/global.scss ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!../node_modules/postcss-loader/src??embedded!../node_modules/sass-loader/lib/loader.js??ref--14-3!./global.scss */ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/global.scss");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./src/theme/variables.scss":
/*!**********************************!*\
  !*** ./src/theme/variables.scss ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!../../node_modules/postcss-loader/src??embedded!../../node_modules/sass-loader/lib/loader.js??ref--14-3!./variables.scss */ "./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/lib/loader.js?!./src/theme/variables.scss");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ 2:
/*!**********************************************************!*\
  !*** multi ./src/theme/variables.scss ./src/global.scss ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! C:\Users\Hasan_Monster\CHAP\src\theme\variables.scss */"./src/theme/variables.scss");
module.exports = __webpack_require__(/*! C:\Users\Hasan_Monster\CHAP\src\global.scss */"./src/global.scss");


/***/ })

},[[2,"runtime"]]]);
//# sourceMappingURL=styles.js.map